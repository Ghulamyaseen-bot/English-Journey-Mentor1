# English Journey – Android APK Build

This project is configured for Expo EAS Android builds.

## Build an installable APK

Run EAS from this directory:

```bash
cd artifacts/english-journey
npx eas login
npx eas build:configure
npx eas build --platform android --profile preview
```

The `preview` profile creates an `.apk` file.

## AI/backend note

The app reads `EXPO_PUBLIC_API_URL` at build/runtime for its learning AI API. An APK can install without it, but AI features that require the backend will not work until a reachable HTTPS API server is configured.

Do not put an OpenAI API key directly in the mobile app. Keep provider API keys on the server.
