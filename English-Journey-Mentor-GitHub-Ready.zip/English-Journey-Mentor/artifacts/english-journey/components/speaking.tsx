import { Feather } from '@expo/vector-icons';
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from 'expo-audio';
import React, { useState } from 'react';
import { Alert, Linking, Platform, Text, View } from 'react-native';
import {
  ActionButton,
  Banner,
  Card,
  Chip,
  Heading,
  Page,
  ProgressBar,
} from '@/components/ui';
import { learningColors } from '@/constants/colors';
import { useLearning } from '@/context/LearningContext';
import { getNetworkMessage, useLearningAI } from '@/hooks/useLearningAI';
import { useColors } from '@/hooks/useColors';

type RecordingPermission = { granted: boolean; canAskAgain: boolean };
type SpeakingResult = { transcript: string; feedback: string; corrections: string[]; focus: string; score: number };

export function SpeakingRecorder({
  prompt,
  trackProgress = true,
  onEvaluated,
}: {
  prompt: string;
  trackProgress?: boolean;
  onEvaluated?: (result: SpeakingResult) => void;
}) {
  const colors = useColors();
  const { state, completeActivity, rememberMistake } = useLearning();
  const { askCoach, transcribeRecording, busy } = useLearningAI();
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const recordingState = useAudioRecorderState(recorder);
  const [permission, setPermission] = useState<RecordingPermission | null>(null);
  const [recordingUri, setRecordingUri] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [corrections, setCorrections] = useState<string[]>([]);
  const [focus, setFocus] = useState<string>('');
  const [score, setScore] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState<boolean>(false);

  const beginRecording = async () => {
    setError(null);
    setStarting(true);
    try {
      const response = await requestRecordingPermissionsAsync();
      setPermission(response);
      if (!response.granted) {
        setError(response.canAskAgain
          ? 'Microphone access is needed to record a spoken answer. You can ask again when you are ready.'
          : 'Microphone access is turned off for this app. Open Android settings to allow it.');
        return;
      }
      await recorder.prepareToRecordAsync();
      recorder.record();
      setRecordingUri(null);
      setTranscript('');
      setFeedback(null);
      setScore(null);
    } catch {
      setError('The microphone could not start. Check that another app is not using it, then try again.');
    } finally {
      setStarting(false);
    }
  };

  const reviewRecording = async (uri: string) => {
    setError(null);
    setFeedback(null);
    try {
      const transcribed = await transcribeRecording(uri);
      const spokenWords = transcribed.transcript.trim();
      if (!spokenWords) {
        setError('No clear speech was found. Try a quieter place and record one short sentence.');
        return;
      }
      setTranscript(spokenWords);
      const result = await askCoach(
        'speaking',
        spokenWords,
        state.profile?.level ?? 1,
        `Speaking prompt: ${prompt}. Assess clarity, grammar, vocabulary and sentence structure fairly. Never penalize an accent.`,
      );
      setFeedback(result.feedback);
      setCorrections(result.corrections);
      setFocus(result.focus);
      setScore(result.score);
      result.corrections.forEach(rememberMistake);
      if (trackProgress) completeActivity('speaking', 12, 'speaking', result.score);
      onEvaluated?.({
        transcript: spokenWords,
        feedback: result.feedback,
        corrections: result.corrections,
        focus: result.focus,
        score: result.score,
      });
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  const stopRecording = async () => {
    try {
      await recorder.stop();
      const uri = recorder.uri;
      if (!uri) {
        setError('The recording was not saved. Please record your answer again.');
        return;
      }
      setRecordingUri(uri);
      await reviewRecording(uri);
    } catch {
      setError('The recording could not be saved. Please try again.');
    }
  };

  const openSettings = async () => {
    if (Platform.OS === 'web') return;
    try {
      await Linking.openSettings();
    } catch {
      Alert.alert('Open Android settings', 'Find English Journey in your app settings and allow microphone access.');
    }
  };

  const seconds = Math.floor(recordingState.durationMillis / 1000);
  const clock = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

  return (
    <View>
      <Card>
        <Text style={{ color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>SPEAKING PROMPT</Text>
        <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: '700', lineHeight: 23, marginTop: 6 }}>{prompt}</Text>
        <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 17, marginTop: 7 }}>Speak naturally for 10–45 seconds. Your answer is transcribed for feedback; accent is not scored.</Text>
      </Card>
      <Card style={{ alignItems: 'center', paddingVertical: 20 }}>
        <View style={{ width: 64, height: 64, borderRadius: 23, backgroundColor: recordingState.isRecording ? colors.dangerSoft : colors.blueSoft, alignItems: 'center', justifyContent: 'center' }}>
          <Feather name={recordingState.isRecording ? 'mic' : 'mic'} size={28} color={recordingState.isRecording ? colors.destructive : colors.primary} />
        </View>
        <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: '800', marginTop: 12 }}>
          {recordingState.isRecording ? clock : 'Your turn to speak'}
        </Text>
        <Text style={{ color: colors.mutedForeground, fontSize: 11, marginTop: 4 }}>
          {recordingState.isRecording ? 'Recording on this device' : permission?.granted ? 'Microphone access is ready' : 'Microphone permission is requested only when you start'}
        </Text>
        <View style={{ width: '100%', marginTop: 18 }}>
          {recordingState.isRecording ? (
            <ActionButton title="Stop and review answer" icon="square" variant="dark" onPress={stopRecording} />
          ) : (
            <ActionButton title={starting ? 'Starting microphone…' : 'Start microphone'} icon="mic" onPress={beginRecording} loading={starting} disabled={starting || busy} testID="start-speaking-recording" />
          )}
        </View>
      </Card>
      {permission && !permission.granted && !permission.canAskAgain ? (
        <ActionButton title="Open Android settings" icon="settings" variant="outline" onPress={openSettings} style={{ marginBottom: 12 }} />
      ) : null}
      {busy ? <Banner icon="loader" title="Reviewing your answer" body="Transcribing your recording and preparing speaking feedback." /> : null}
      {error ? (
        <>
          <Banner icon="wifi-off" title="Could not review this recording" body={error} tone="orange" />
          {recordingUri ? <ActionButton title="Retry feedback" icon="refresh-cw" variant="outline" onPress={() => reviewRecording(recordingUri)} disabled={busy} style={{ marginBottom: 12 }} /> : null}
        </>
      ) : null}
      {feedback ? (
        <Card>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: '800' }}>Speaking feedback</Text>
            <Text style={{ color: learningColors.speaking, fontSize: 21, fontWeight: '800' }}>{score}%</Text>
          </View>
          <ProgressBar value={score ?? 0} color={learningColors.speaking} />
          <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20, marginTop: 12 }}>{feedback}</Text>
          {transcript ? (
            <View style={{ padding: 11, backgroundColor: colors.secondary, borderRadius: 13, marginTop: 12 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 10, fontWeight: '800', letterSpacing: 0.7 }}>YOUR TRANSCRIPT</Text>
              <Text style={{ color: colors.foreground, fontSize: 12, lineHeight: 18, marginTop: 5 }}>{transcript}</Text>
            </View>
          ) : null}
          {corrections.length ? (
            <View style={{ marginTop: 13 }}>
              <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: '800', marginBottom: 6 }}>Try these improvements</Text>
              {corrections.map((item, index) => <Text key={`${item}-${index}`} style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18, marginBottom: 4 }}>• {item}</Text>)}
            </View>
          ) : null}
          {focus ? <Banner icon="target" title="Next practice" body={focus} tone="green" /> : null}
          <ActionButton title="Try another answer" icon="rotate-ccw" variant="secondary" onPress={() => { setFeedback(null); setTranscript(''); setScore(null); setError(null); setRecordingUri(null); }} style={{ marginTop: 8 }} />
        </Card>
      ) : null}
    </View>
  );
}

export default function SpeakScreen() {
  const { state } = useLearning();
  return (
    <Page>
      <Heading eyebrow="Real microphone practice" title="Speak with confidence" subtitle="Record a short answer and get clear, level-aware feedback." />
      <Banner icon="shield" tone="blue" title="Your recording is used for feedback" body="The audio is sent to the learning server only when you submit it for transcription. It is not saved as a public post." />
      <View style={{ flexDirection: 'row', gap: 7, marginBottom: 10 }}>
        <Chip title={`Level ${state.profile?.level ?? 1}`} selected />
        <Chip title="Accent is not scored" />
        <Chip title="10–45 sec" />
      </View>
      <SpeakingRecorder prompt="Describe a goal you are working toward and one step you can take this week." />
      <View style={{ height: 16 }} />
    </Page>
  );
}