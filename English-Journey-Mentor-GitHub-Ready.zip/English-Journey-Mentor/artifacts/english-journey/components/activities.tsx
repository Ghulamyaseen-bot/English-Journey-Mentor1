import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import {
  ActionButton,
  Banner,
  Card,
  Chip,
  Field,
  Heading,
  LessonCard,
  Page,
  ProgressBar,
  SmallHeader,
} from '@/components/ui';
import { learningColors } from '@/constants/colors';
import {
  GRAMMAR_TOPICS,
  PASSAGES,
  WORDS,
  WRITING_PROMPTS,
  type GrammarTopic,
  type ReadingPassage,
  type VocabularyWord,
} from '@/constants/learning';
import { useLearning } from '@/context/LearningContext';
import { getNetworkMessage, useLearningAI } from '@/hooks/useLearningAI';
import { useColors } from '@/hooks/useColors';

export type PracticeMode = 'vocabulary' | 'review' | 'reading' | 'grammar' | 'writing' | 'ielts';

function ChoiceButton({
  title,
  selected,
  disabled,
  onPress,
}: {
  title: string;
  selected?: boolean;
  disabled?: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected, disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => ({
        minHeight: 47,
        borderWidth: 1,
        borderColor: selected ? colors.primary : colors.border,
        backgroundColor: selected ? colors.accent : colors.card,
        borderRadius: 14,
        paddingHorizontal: 13,
        paddingVertical: 10,
        justifyContent: 'center',
        opacity: disabled ? 0.75 : pressed ? 0.72 : 1,
      })}
    >
      <Text style={{ color: selected ? colors.accentForeground : colors.foreground, fontSize: 13, fontWeight: selected ? '700' : '500', lineHeight: 19 }}>{title}</Text>
    </Pressable>
  );
}

export function LearnScreen() {
  const { state } = useLearning();
  const colors = useColors();
  const level = state.profile?.level ?? 1;
  const goToPractice = () => router.navigate('/(tabs)/practice');
  return (
    <Page>
      <Heading eyebrow="Your learning path" title="Learn at your pace" subtitle={`Level ${level} lessons stay saved on this device.`} />
      <Banner icon="download" tone="green" title="Works offline" body="Vocabulary, reading passages and grammar lessons are ready without a connection." />
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <View>
            <Text style={{ color: colors.mutedForeground, fontSize: 10, fontWeight: '700', letterSpacing: 0.7 }}>YOUR COURSE</Text>
            <Text style={{ color: colors.foreground, fontSize: 19, fontWeight: '800', marginTop: 4 }}>Level {level} · 8 levels</Text>
            <Text style={{ color: colors.mutedForeground, fontSize: 12, marginTop: 3 }}>Current level adapts after check-ins.</Text>
          </View>
          <View style={{ width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.blueSoft }}>
            <Feather name="map" size={21} color={colors.primary} />
          </View>
        </View>
      </Card>
      <Heading eyebrow="Modules" title="Choose what to practise" />
      <View style={{ gap: 9 }}>
        <LessonCard title="Vocabulary" subtitle="Word cards, examples, matching and a quiz" icon="book" color={learningColors.vocabulary} onPress={goToPractice} />
        <LessonCard title="Reading" subtitle="Short passages, comprehension and reading pace" icon="book-open" color={learningColors.reading} onPress={goToPractice} />
        <LessonCard title="Grammar" subtitle="Clear rules, examples and mistake reviews" icon="layers" color={learningColors.grammar} onPress={goToPractice} />
        <LessonCard title="Writing" subtitle="Prompts, saved drafts and AI feedback" icon="edit-3" color={learningColors.writing} onPress={goToPractice} />
        <LessonCard title="Speaking" subtitle="Record a real answer and review your transcript" icon="mic" color={learningColors.speaking} onPress={() => router.navigate('/(tabs)/speak')} />
        <LessonCard title="AI Interview" subtitle="One question at a time with level-aware feedback" icon="message-circle" color={learningColors.interview} onPress={() => router.navigate('/(tabs)/interview')} />
        <LessonCard title="Mistake review" subtitle="Revisit words and corrections you have saved" icon="rotate-ccw" color={colors.warning} onPress={goToPractice} />
        <LessonCard
          title="IELTS preparation"
          subtitle={level >= 4 ? 'Academic reading, writing and speaking practice' : `Unlocks at Level 4 · currently Level ${level}`}
          icon="award"
          color={colors.navy}
          locked={level < 4}
          onPress={() => {
            if (level < 4) {
              Alert.alert('IELTS path is locked', 'Complete the Level 4 check-in to unlock IELTS-focused practice. Your current course lessons are available now.');
              return;
            }
            router.push('/ielts');
          }}
        />
      </View>
      <View style={{ marginTop: 15 }}>
        <ActionButton title="Open practice centre" icon="target" onPress={goToPractice} />
      </View>
    </Page>
  );
}

export function PracticeScreen() {
  const { state } = useLearning();
  const colors = useColors();
  const [mode, setMode] = useState<PracticeMode | null>(null);
  const level = state.profile?.level ?? 1;
  if (mode) {
    const title = mode === 'review' ? 'Mistake review' : mode === 'ielts' ? 'IELTS preparation' : `${mode[0].toUpperCase()}${mode.slice(1)} practice`;
    return (
      <Page>
        <SmallHeader title={title} back={() => setMode(null)} />
        {mode === 'vocabulary' ? <VocabularyTrainer /> : null}
        {mode === 'review' ? <MistakeReview /> : null}
        {mode === 'reading' ? <ReadingTrainer /> : null}
        {mode === 'grammar' ? <GrammarTrainer /> : null}
        {mode === 'writing' ? <WritingTrainer /> : null}
        {mode === 'ielts' ? <IELTSPractice /> : null}
      </Page>
    );
  }

  return (
    <Page>
      <Heading eyebrow="Practice centre" title="Build real skills" subtitle="Every answer helps your next session adapt." />
      <Card style={{ backgroundColor: colors.navy, borderColor: colors.navy }}>
        <Text style={{ color: colors.primaryForeground, fontSize: 11, fontWeight: '700', letterSpacing: 0.8 }}>LEVEL {level}</Text>
        <Text style={{ color: colors.primaryForeground, fontSize: 20, fontWeight: '800', marginTop: 5 }}>Choose one focused practice</Text>
        <Text style={{ color: colors.primaryForeground, opacity: 0.82, fontSize: 12, lineHeight: 18, marginTop: 5 }}>Your scores, word memory and mistakes are saved locally.</Text>
      </Card>
      <View style={{ gap: 9 }}>
        <LessonCard title="Vocabulary quiz" subtitle="Definitions, context, fill-in-the-blank and matching" icon="book" color={learningColors.vocabulary} onPress={() => setMode('vocabulary')} />
        <LessonCard title="Reading comprehension" subtitle="Main idea, detail, inference and true / false" icon="book-open" color={learningColors.reading} onPress={() => setMode('reading')} />
        <LessonCard title="Grammar lesson" subtitle="Rule, example, answer and correction" icon="layers" color={learningColors.grammar} onPress={() => setMode('grammar')} />
        <LessonCard title="Writing studio" subtitle="Write, get AI feedback and revisit your work" icon="edit-3" color={learningColors.writing} onPress={() => setMode('writing')} />
        <LessonCard title="Review mistakes" subtitle="Retry vocabulary that needs another look" icon="rotate-ccw" color={colors.warning} onPress={() => setMode('review')} />
        {level >= 4 ? (
          <LessonCard title="IELTS practice" subtitle="Academic reading, Task 2 writing and speaking prompts" icon="award" color={colors.navy} onPress={() => setMode('ielts')} />
        ) : (
          <Card style={{ marginTop: 2 }}>
            <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700' }}>IELTS practice unlocks at Level 4</Text>
            <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 16, marginTop: 4 }}>Build your foundation first. A full skill check can move you forward when you are ready.</Text>
          </Card>
        )}
      </View>
    </Page>
  );
}

export function VocabularyTrainer({ reviewOnly = false }: { reviewOnly?: boolean }) {
  const { state, recordWordAnswer, completeActivity, rememberMistake } = useLearning();
  const colors = useColors();
  const [cardIndex, setCardIndex] = useState<number>(0);
  const [quizIndex, setQuizIndex] = useState<number>(0);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState<boolean>(false);
  const [finished, setFinished] = useState<boolean>(false);
  const [quizMode, setQuizMode] = useState<boolean>(false);

  const availableWords = useMemo(() => {
    const level = state.profile?.level ?? 1;
    const wordCount = Math.min(WORDS.length, 5 + Math.ceil(((level - 1) * (WORDS.length - 5)) / 7));
    const accessible = WORDS.slice(0, wordCount);
    if (!reviewOnly) return accessible;
    const weakWords = accessible.filter((word) => {
      const record = state.wordMemory[word.id];
      return record && record.incorrect > record.correct;
    });
    return weakWords.length ? weakWords : accessible.slice(0, 4);
  }, [reviewOnly, state.profile?.level, state.wordMemory]);

  const index = quizMode ? quizIndex : cardIndex;
  const word = availableWords[index % availableWords.length];
  if (!word) return null;

  const distractors = WORDS.filter((item) => item.id !== word.id).slice((index * 2) % (WORDS.length - 3), ((index * 2) % (WORDS.length - 3)) + 3);
  const options: VocabularyWord[] = index % 2 === 0
    ? [...distractors, word]
    : [word, ...distractors];
  const questionType = index % 3;
  const blankExample = word.example.replace(new RegExp(word.word, 'ig'), '_____');
  const prompt = questionType === 0
    ? `Which word means: “${word.definition}”`
    : questionType === 1
      ? `Complete the sentence: “${blankExample}”`
      : `Match “${word.word}” to its meaning.`;
  const correctIndex = options.findIndex((item) => item.id === word.id);

  const answerWord = (known: boolean) => {
    recordWordAnswer(word.id, known);
    if (!known) rememberMistake(`Vocabulary: review the meaning and use of “${word.word}”. ${word.definition}`);
    if (cardIndex >= availableWords.length - 1) {
      completeActivity(reviewOnly ? 'review' : 'vocabulary', 12, 'vocabulary', Math.round((availableWords.filter((item) => (state.wordMemory[item.id]?.correct ?? 0) > 0).length / availableWords.length) * 100));
      setCardIndex(0);
    } else {
      setCardIndex((previous) => previous + 1);
    }
    setRevealed(false);
  };

  const answerQuiz = (answer: number) => {
    if (selected !== null) return;
    setSelected(answer);
    const correct = answer === correctIndex;
    if (correct) setQuizScore((previous) => previous + 1);
    recordWordAnswer(word.id, correct);
    if (!correct) rememberMistake(`Vocabulary: “${word.word}” means ${word.definition}`);
  };

  const nextQuestion = () => {
    const nextIndex = quizIndex + 1;
    if (nextIndex >= availableWords.length) {
      const score = Math.round((quizScore / availableWords.length) * 100);
      completeActivity(reviewOnly ? 'review' : 'vocabulary', 18, 'vocabulary', score);
      setFinished(true);
      return;
    }
    setQuizIndex(nextIndex);
    setSelected(null);
  };

  if (finished) {
    return (
      <Card>
        <View style={{ alignItems: 'center', paddingVertical: 14 }}>
          <Feather name="check-circle" size={34} color={colors.success} />
          <Text style={{ color: colors.foreground, fontSize: 21, fontWeight: '800', marginTop: 10 }}>Quiz complete</Text>
          <Text style={{ color: colors.mutedForeground, fontSize: 13, marginTop: 5 }}>{quizScore} of {availableWords.length} correct</Text>
          <View style={{ width: '100%', marginTop: 15 }}>
            <ProgressBar value={(quizScore / availableWords.length) * 100} color={learningColors.vocabulary} />
          </View>
          <ActionButton title="Try the quiz again" icon="rotate-ccw" onPress={() => { setQuizIndex(0); setQuizScore(0); setSelected(null); setFinished(false); }} style={{ width: '100%', marginTop: 18 }} />
        </View>
      </Card>
    );
  }

  return (
    <View>
      <View style={{ flexDirection: 'row', gap: 8, marginBottom: 12 }}>
        <Chip title="Word cards" selected={!quizMode} onPress={() => setQuizMode(false)} />
        <Chip title="Quiz" selected={quizMode} onPress={() => setQuizMode(true)} />
      </View>
      {reviewOnly ? (
        <Banner
          icon="rotate-ccw"
          tone="orange"
          title={availableWords.some((item) => (state.wordMemory[item.id]?.incorrect ?? 0) > (state.wordMemory[item.id]?.correct ?? 0)) ? 'Reviewing your weaker words' : 'A short refresher'}
          body="Words you miss are saved here for another try."
        />
      ) : null}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
        <Text style={{ color: colors.mutedForeground, fontSize: 11, fontWeight: '700' }}>{quizMode ? 'QUESTION' : 'WORD'} {index + 1} OF {availableWords.length}</Text>
        <Text style={{ color: colors.primary, fontSize: 11, fontWeight: '700' }}>{word.difficulty}</Text>
      </View>
      <Card>
        {quizMode ? (
          <>
            <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: '800', lineHeight: 23 }}>{prompt}</Text>
            <View style={{ gap: 8, marginTop: 16 }}>
              {options.map((option, optionIndex) => (
                <ChoiceButton
                  key={option.id}
                  title={questionType === 1 ? option.word : option.definition}
                  selected={selected === optionIndex || (selected !== null && optionIndex === correctIndex)}
                  disabled={selected !== null}
                  onPress={() => answerQuiz(optionIndex)}
                />
              ))}
            </View>
            {selected !== null ? (
              <Banner
                icon={selected === correctIndex ? 'check' : 'info'}
                tone={selected === correctIndex ? 'green' : 'orange'}
                title={selected === correctIndex ? 'That is right' : `The answer is ${word.word}`}
                body={`${word.word}: ${word.definition}`}
              />
            ) : null}
            {selected !== null ? <ActionButton title={quizIndex === availableWords.length - 1 ? 'Finish quiz' : 'Next question'} icon="arrow-right" onPress={nextQuestion} style={{ marginTop: 13 }} /> : null}
          </>
        ) : (
          <>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontSize: 27, fontWeight: '800' }}>{word.word}</Text>
                <Text style={{ color: colors.primary, fontSize: 12, fontWeight: '700', marginTop: 3 }}>{word.pronunciation} · {word.partOfSpeech}</Text>
              </View>
              <View style={{ backgroundColor: colors.blueSoft, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7 }}>
                <Text style={{ color: colors.accentForeground, fontSize: 15, fontWeight: '700' }}>{word.urdu}</Text>
              </View>
            </View>
            <Text style={{ color: colors.foreground, fontSize: 15, lineHeight: 23, marginTop: 16 }}>{word.definition}</Text>
            <View style={{ backgroundColor: colors.secondary, padding: 12, borderRadius: 14, marginTop: 12 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 10, fontWeight: '800', letterSpacing: 0.7 }}>IN A SENTENCE</Text>
              <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20, marginTop: 5 }}>{word.example}</Text>
            </View>
            {revealed ? (
              <View style={{ gap: 8, marginTop: 13 }}>
                <Text style={{ color: colors.foreground, fontSize: 12 }}><Text style={{ fontWeight: '800' }}>Similar: </Text>{word.synonyms.join(', ')}</Text>
                <Text style={{ color: colors.foreground, fontSize: 12 }}><Text style={{ fontWeight: '800' }}>Opposite: </Text>{word.antonyms.join(', ')}</Text>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <ActionButton title="I know it" icon="check" variant="primary" onPress={() => answerWord(true)} style={{ flex: 1 }} />
                  <ActionButton title="Review again" icon="rotate-ccw" variant="secondary" onPress={() => answerWord(false)} style={{ flex: 1 }} />
                </View>
              </View>
            ) : (
              <ActionButton title="Show memory check" icon="eye" variant="secondary" onPress={() => setRevealed(true)} style={{ marginTop: 14 }} />
            )}
          </>
        )}
      </Card>
      <Text style={{ color: colors.mutedForeground, fontSize: 11, textAlign: 'center', marginTop: 1 }}>
        Correct answers strengthen word memory. Missed words return in review.
      </Text>
    </View>
  );
}

export function MistakeReview() {
  const { state, resolveMistakeAt, completeActivity } = useLearning();
  const colors = useColors();
  const [reviewWords, setReviewWords] = useState<boolean>(false);
  const mistakes = state.mistakeMemory;

  if (reviewWords || mistakes.length === 0) {
    return (
      <View>
        {mistakes.length === 0 ? (
          <Banner icon="check-circle" tone="green" title="No saved corrections to review" body="Try a vocabulary refresher now. Any missed words or lesson corrections will appear here next time." />
        ) : (
          <ActionButton title="Back to saved corrections" icon="arrow-left" variant="outline" onPress={() => setReviewWords(false)} style={{ marginBottom: 12 }} />
        )}
        <VocabularyTrainer reviewOnly />
      </View>
    );
  }

  return (
    <View>
      <Banner icon="rotate-ccw" tone="orange" title={`${mistakes.length} saved ${mistakes.length === 1 ? 'correction' : 'corrections'}`} body="Read each correction, then mark it reviewed. New mistakes are added automatically as you practise." />
      {mistakes.map((mistake, index) => (
        <Card key={`${mistake}-${index}`}>
          <View style={{ flexDirection: 'row', gap: 9, alignItems: 'flex-start' }}>
            <View style={{ width: 30, height: 30, borderRadius: 11, backgroundColor: colors.warningSoft, alignItems: 'center', justifyContent: 'center' }}>
              <Feather name="alert-circle" size={15} color={colors.warning} />
            </View>
            <Text style={{ flex: 1, color: colors.foreground, fontSize: 13, lineHeight: 20 }}>{mistake}</Text>
          </View>
          <ActionButton
            title="Mark reviewed"
            icon="check"
            variant="secondary"
            onPress={() => {
              resolveMistakeAt(index);
              completeActivity('review', 2);
            }}
            style={{ marginTop: 12 }}
          />
        </Card>
      ))}
      <ActionButton title="Review vocabulary too" icon="book" variant="outline" onPress={() => setReviewWords(true)} style={{ marginTop: 2 }} />
    </View>
  );
}

export function ReadingTrainer({ ielts = false }: { ielts?: boolean }) {
  const { state, completeActivity, rememberMistake } = useLearning();
  const colors = useColors();
  const level = state.profile?.level ?? 1;
  const accessible = PASSAGES.filter((passage) => passage.level <= level);
  const readingList = accessible.length ? accessible : PASSAGES.slice(0, 1);
  const [passageIndex, setPassageIndex] = useState<number>(0);
  const [questionIndex, setQuestionIndex] = useState<number>(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [started, setStarted] = useState<boolean>(false);
  const [finished, setFinished] = useState<boolean>(false);
  const [finalScore, setFinalScore] = useState<number>(0);
  const [finalWpm, setFinalWpm] = useState<number>(0);
  const startedAt = useRef<number>(Date.now());
  const passage: ReadingPassage = readingList[passageIndex % readingList.length];
  const question = passage.questions[questionIndex];
  const wordCount = passage.text.split(/\s+/).length;

  const selectAnswer = (answer: number) => {
    if (selected !== null) return;
    setSelected(answer);
    if (answer === question.answer) setScore((previous) => previous + 1);
    else rememberMistake(`Reading: ${passage.title} · ${question.prompt} Correct answer: ${question.options[question.answer]}`);
  };

  const next = () => {
    if (questionIndex < passage.questions.length - 1) {
      setQuestionIndex((previous) => previous + 1);
      setSelected(null);
      return;
    }
    const resultScore = Math.round((score / passage.questions.length) * 100);
    const minutesElapsed = Math.max(1, (Date.now() - startedAt.current) / 60_000);
    const wpm = Math.round(wordCount / minutesElapsed);
    completeActivity('reading', Math.max(1, Math.round(minutesElapsed)), 'reading', resultScore, wpm);
    setFinalScore(resultScore);
    setFinalWpm(wpm);
    setFinished(true);
  };

  if (!started) {
    return (
      <View>
        {ielts ? <Banner icon="award" title="IELTS Academic reading" body="Look for the main claim, supporting detail, vocabulary in context and careful evidence." /> : null}
        <Text style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18, marginBottom: 12 }}>Choose a passage at or below your current level. You can return for another one later.</Text>
        <View style={{ gap: 8 }}>
          {readingList.map((item, index) => (
            <LessonCard
              key={item.title}
              title={item.title}
              subtitle={`${item.topic} · ${item.questions.length} questions · Level ${item.level}`}
              icon="book-open"
              color={learningColors.reading}
              onPress={() => {
                setPassageIndex(index);
                setQuestionIndex(0);
                setSelected(null);
                setScore(0);
                setFinished(false);
                setStarted(true);
                startedAt.current = Date.now();
              }}
            />
          ))}
        </View>
      </View>
    );
  }

  if (finished) {
    return (
      <View>
        <Card style={{ alignItems: 'center', paddingVertical: 19 }}>
          <Feather name="check-circle" size={34} color={colors.success} />
          <Text style={{ color: colors.foreground, fontSize: 20, fontWeight: '800', marginTop: 10 }}>Passage complete</Text>
          <Text style={{ color: colors.primary, fontSize: 15, fontWeight: '800', marginTop: 5 }}>{finalScore}% comprehension · about {finalWpm} words per minute</Text>
          <Text style={{ color: colors.mutedForeground, fontSize: 12, textAlign: 'center', lineHeight: 18, marginTop: 8 }}>You can choose another passage or return to your other practice.</Text>
          <ActionButton title="Choose another passage" icon="book-open" onPress={() => { setStarted(false); setFinished(false); setQuestionIndex(0); setSelected(null); setScore(0); }} style={{ width: '100%', marginTop: 15 }} />
        </Card>
      </View>
    );
  }

  return (
    <View>
      {ielts ? <Banner icon="award" title="IELTS Academic reading" body="Look for the main claim, supporting detail, vocabulary in context and careful evidence." /> : null}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
        <Text style={{ color: colors.mutedForeground, fontSize: 11, fontWeight: '700' }}>PASSAGE {passageIndex + 1} OF {readingList.length}</Text>
        <Text style={{ color: colors.primary, fontSize: 11, fontWeight: '700' }}>{passage.topic}</Text>
      </View>
      <Card>
        <Text style={{ color: colors.foreground, fontSize: 19, fontWeight: '800' }}>{passage.title}</Text>
        <Text style={{ color: colors.mutedForeground, fontSize: 10, marginTop: 3 }}>{wordCount} words · Level {passage.level}</Text>
        <Text style={{ color: colors.foreground, fontSize: 14, lineHeight: 22, marginTop: 14 }}>{passage.text}</Text>
      </Card>
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 7 }}>
          <Text style={{ color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>{question.type.toUpperCase()}</Text>
          <Text style={{ color: colors.mutedForeground, fontSize: 10 }}>{questionIndex + 1}/{passage.questions.length}</Text>
        </View>
        <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '700', lineHeight: 22 }}>{question.prompt}</Text>
        <View style={{ gap: 8, marginTop: 13 }}>
          {question.options.map((option, index) => (
            <ChoiceButton key={`${question.prompt}-${option}`} title={option} selected={selected === index || (selected !== null && question.answer === index)} disabled={selected !== null} onPress={() => selectAnswer(index)} />
          ))}
        </View>
        {selected !== null ? (
          <>
            <Banner icon={selected === question.answer ? 'check' : 'book-open'} tone={selected === question.answer ? 'green' : 'orange'} title={selected === question.answer ? 'Correct' : 'Read the evidence again'} body={question.explanation} />
            <ActionButton title={questionIndex === passage.questions.length - 1 ? (passageIndex === readingList.length - 1 ? 'Finish reading' : 'Next passage') : 'Next question'} icon="arrow-right" onPress={next} />
          </>
        ) : null}
      </Card>
    </View>
  );
}

export function GrammarTrainer() {
  const { state, completeActivity, rememberMistake } = useLearning();
  const colors = useColors();
  const level = state.profile?.level ?? 1;
  const topics = GRAMMAR_TOPICS.filter((topic) => topic.level <= level);
  const [selectedTopic, setSelectedTopic] = useState<GrammarTopic | null>(null);
  const [answer, setAnswer] = useState<number | null>(null);
  const topicList = topics.length ? topics : GRAMMAR_TOPICS.slice(0, 3);

  if (!selectedTopic) {
    return (
      <View>
        <Text style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18, marginBottom: 13 }}>Choose a short lesson. Every answer includes the rule, a corrected form and a practice prompt.</Text>
        <View style={{ gap: 8 }}>
          {topicList.map((topic) => (
            <Pressable key={topic.title} accessibilityRole="button" onPress={() => { setSelectedTopic(topic); setAnswer(null); }}>
              <Card style={{ marginBottom: 0, padding: 14 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: '700' }}>{topic.title}</Text>
                    <Text style={{ color: colors.mutedForeground, fontSize: 11, marginTop: 3 }}>Level {topic.level}</Text>
                  </View>
                  <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
                </View>
              </Card>
            </Pressable>
          ))}
        </View>
      </View>
    );
  }

  const submit = () => {
    if (answer === null) return;
    const correct = answer === selectedTopic.answer;
    completeActivity('grammar', 10, 'grammar', correct ? 100 : 0);
    if (!correct) rememberMistake(`Grammar · ${selectedTopic.title}: ${selectedTopic.prompt} Correct form: ${selectedTopic.options[selectedTopic.answer]}. ${selectedTopic.rule}`);
  };
  return (
    <View>
      <ActionButton title="All grammar topics" icon="arrow-left" variant="outline" onPress={() => { setSelectedTopic(null); setAnswer(null); }} style={{ marginBottom: 12 }} />
      <Card>
        <Text style={{ color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>RULE</Text>
        <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '700', lineHeight: 22, marginTop: 5 }}>{selectedTopic.rule}</Text>
        <View style={{ backgroundColor: colors.secondary, borderRadius: 13, padding: 12, marginTop: 11 }}>
          <Text style={{ color: colors.mutedForeground, fontSize: 10, fontWeight: '700' }}>EXAMPLE</Text>
          <Text style={{ color: colors.foreground, fontSize: 14, marginTop: 5 }}>{selectedTopic.example}</Text>
        </View>
      </Card>
      <Card>
        <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '700', lineHeight: 22 }}>{selectedTopic.prompt}</Text>
        <View style={{ gap: 8, marginTop: 12 }}>
          {selectedTopic.options.map((option, index) => (
            <ChoiceButton key={option} title={option} selected={answer === index || (answer !== null && selectedTopic.answer === index)} onPress={() => setAnswer(index)} />
          ))}
        </View>
        {answer !== null ? (
          <>
            <Banner icon={answer === selectedTopic.answer ? 'check' : 'alert-circle'} tone={answer === selectedTopic.answer ? 'green' : 'orange'} title={answer === selectedTopic.answer ? 'Correct' : 'A useful correction'} body={selectedTopic.correction} />
            <Text style={{ color: colors.foreground, fontSize: 12, lineHeight: 18, marginBottom: 12 }}><Text style={{ fontWeight: '800' }}>Try it: </Text>{selectedTopic.practice}</Text>
            <ActionButton title="Save lesson result" icon="check" onPress={submit} />
          </>
        ) : null}
      </Card>
    </View>
  );
}

export function WritingTrainer({ ielts = false }: { ielts?: boolean }) {
  const { state, completeActivity, rememberMistake, saveWritingDraft, saveWritingSubmission } = useLearning();
  const colors = useColors();
  const { askCoach, busy } = useLearningAI();
  const ieltsPrompt = 'Some people believe that online learning is as effective as classroom learning. Discuss both views and give your own opinion.';
  const savedDraft = state.writingSubmissions.find((item) => item.status === 'draft');
  const [promptIndex, setPromptIndex] = useState<number>(() => {
    if (ielts || !savedDraft?.prompt) return 0;
    return Math.max(0, WRITING_PROMPTS.indexOf(savedDraft.prompt));
  });
  const prompt = ielts
    ? ieltsPrompt
    : WRITING_PROMPTS[promptIndex % WRITING_PROMPTS.length];
  const [draft, setDraft] = useState<string>(() => {
    if (!savedDraft || (ielts && savedDraft.prompt !== ieltsPrompt)) return '';
    if (!ielts && savedDraft.prompt && !WRITING_PROMPTS.includes(savedDraft.prompt as typeof WRITING_PROMPTS[number])) return '';
    return savedDraft.text;
  });
  const [feedback, setFeedback] = useState<string | null>(null);
  const [score, setScore] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const level = state.profile?.level ?? 1;
  useEffect(() => {
    if (!draft.trim()) return;
    const timeout = setTimeout(() => saveWritingDraft(prompt, draft), 650);
    return () => clearTimeout(timeout);
  }, [draft, prompt, saveWritingDraft]);

  const send = async () => {
    if (draft.trim().length < 10) {
      setError('Write at least 10 characters so the coach has enough to review.');
      return;
    }
    setError(null);
    setFeedback(null);
    try {
      const result = await askCoach('writing', draft.trim(), level, `${ielts ? 'IELTS Task 2 practice. Give band-aware feedback.' : 'Short-form writing practice.'} Prompt: ${prompt}`);
      setFeedback(result.feedback);
      setScore(result.score);
      saveWritingSubmission(prompt, draft.trim(), result.score, result.feedback);
      completeActivity('writing', ielts ? 25 : 15, 'writing', result.score);
      result.corrections.forEach(rememberMistake);
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  return (
    <View>
      {ielts ? <Banner icon="award" title="IELTS Writing Task 2" body="Aim for a clear position, developed reasons, specific examples and a concise conclusion." /> : null}
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>{ielts ? 'TASK 2 · ESSAY' : 'WRITING PROMPT'}</Text>
          {!ielts ? <Pressable accessibilityRole="button" onPress={() => { if (draft.trim()) saveWritingDraft(prompt, draft); setDraft(''); setPromptIndex((index) => index + 1); setFeedback(null); setScore(null); setError(null); }}><Text style={{ color: colors.primary, fontSize: 11, fontWeight: '700' }}>New prompt</Text></Pressable> : null}
        </View>
        <Text style={{ color: colors.foreground, fontSize: 15, fontWeight: '700', lineHeight: 22, marginTop: 8 }}>{prompt}</Text>
      </Card>
      <Field
        label="Your response"
        value={draft}
        onChangeText={(text) => { setDraft(text); setFeedback(null); setScore(null); }}
        placeholder={ielts ? 'Write your essay here…' : 'Write a few sentences…'}
        multiline
        textAlignVertical="top"
        maxLength={4000}
        style={{ minHeight: ielts ? 220 : 150, lineHeight: 21 }}
        helper={`${draft.trim().split(/\s+/).filter(Boolean).length} words · Your draft is saved on this device as you write.`}
        testID="writing-response"
      />
      <ActionButton title={busy ? 'Reviewing your writing…' : 'Get AI feedback'} icon="zap" onPress={send} loading={busy} disabled={busy} />
      {error ? <Banner icon="wifi-off" title="Could not get AI feedback" body={error} tone="orange" /> : null}
      {error ? <ActionButton title="Try again" icon="refresh-cw" variant="outline" onPress={send} disabled={busy} /> : null}
      {feedback ? (
        <Card style={{ marginTop: 13 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ color: colors.foreground, fontSize: 16, fontWeight: '800' }}>Coach feedback</Text>
            <Text style={{ color: colors.primary, fontSize: 20, fontWeight: '800' }}>{score}%</Text>
          </View>
          <ProgressBar value={score ?? 0} color={learningColors.writing} />
          <Text style={{ color: colors.foreground, fontSize: 13, lineHeight: 20, marginTop: 12 }}>{feedback}</Text>
          {state.writingSubmissions.length ? (
            <View style={{ marginTop: 16, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 10, fontWeight: '800', letterSpacing: 0.7 }}>RECENT SAVED WORK</Text>
              {state.writingSubmissions.filter((item) => item.status !== 'draft').slice(0, 3).map((item) => (
                <View key={item.id} style={{ marginTop: 10 }}>
                  <Text numberOfLines={2} style={{ color: colors.foreground, fontSize: 12, lineHeight: 18 }}>{item.text}</Text>
                  <Text style={{ color: colors.mutedForeground, fontSize: 10, marginTop: 3 }}>{item.score}% · {new Date(item.date).toLocaleDateString()}</Text>
                </View>
              ))}
            </View>
          ) : null}
        </Card>
      ) : null}
    </View>
  );
}

export function IELTSPractice() {
  const colors = useColors();
  const [section, setSection] = useState<'reading' | 'writing' | 'speaking' | null>(null);
  if (section === 'reading') return <View><ActionButton title="IELTS practice menu" icon="arrow-left" variant="outline" onPress={() => setSection(null)} style={{ marginBottom: 12 }} /><ReadingTrainer ielts /></View>;
  if (section === 'writing') return <View><ActionButton title="IELTS practice menu" icon="arrow-left" variant="outline" onPress={() => setSection(null)} style={{ marginBottom: 12 }} /><WritingTrainer ielts /></View>;
  if (section === 'speaking') {
    return (
      <View>
        <ActionButton title="IELTS practice menu" icon="arrow-left" variant="outline" onPress={() => setSection(null)} style={{ marginBottom: 12 }} />
        <Banner icon="mic" title="IELTS Speaking practice" body="Answer naturally and aim to explain your ideas with relevant detail." />
        <Card>
          {['Describe a skill you would like to learn.', 'Talk about a place where you enjoy studying.', 'How has communication changed in recent years?'].map((prompt) => (
            <Text key={prompt} style={{ color: colors.foreground, fontSize: 13, lineHeight: 19, paddingVertical: 8 }}>{prompt}</Text>
          ))}
          <ActionButton title="Open speaking recorder" icon="mic" onPress={() => router.navigate('/(tabs)/speak')} style={{ marginTop: 8 }} />
        </Card>
      </View>
    );
  }
  return (
    <View>
      <Banner icon="award" title="IELTS preparation is unlocked" body="Practise academic reading, Task 2 writing and speaking. IELTS activities add to your regular skill scores." />
      <View style={{ gap: 9 }}>
        <LessonCard title="Academic reading" subtitle="Evidence, claims and vocabulary in context" icon="book-open" color={learningColors.reading} onPress={() => setSection('reading')} />
        <LessonCard title="Writing Task 2" subtitle="Discuss both views and give an opinion" icon="edit-3" color={learningColors.writing} onPress={() => setSection('writing')} />
        <LessonCard title="Speaking topics" subtitle="Short answers with real microphone practice" icon="mic" color={learningColors.speaking} onPress={() => setSection('speaking')} />
      </View>
    </View>
  );
}