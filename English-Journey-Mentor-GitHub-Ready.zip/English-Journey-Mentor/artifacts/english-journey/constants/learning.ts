export type SkillKey =
  | 'vocabulary'
  | 'reading'
  | 'writing'
  | 'speaking'
  | 'grammar'
  | 'interview';

export const SKILLS: { id: SkillKey; label: string }[] = [
  { id: 'vocabulary', label: 'Vocabulary' },
  { id: 'reading', label: 'Reading' },
  { id: 'grammar', label: 'Grammar' },
  { id: 'writing', label: 'Writing' },
  { id: 'speaking', label: 'Speaking' },
  { id: 'interview', label: 'AI Interview' },
];

export const LEVELS = [
  'Absolute Beginner',
  'Beginner',
  'Elementary',
  'Pre-Intermediate',
  'Intermediate',
  'Upper-Intermediate',
  'Advanced',
  'Professional English',
] as const;

export type DailyTask = {
  id: string;
  title: string;
  minutes: number;
  skill: SkillKey | 'review';
};

const TASK_WEIGHTS = [
  { id: 'vocabulary', title: 'Vocabulary', weight: 20, skill: 'vocabulary' },
  { id: 'reading', title: 'Reading', weight: 25, skill: 'reading' },
  { id: 'grammar', title: 'Grammar', weight: 20, skill: 'grammar' },
  { id: 'writing', title: 'Writing', weight: 25, skill: 'writing' },
  { id: 'speaking', title: 'Speaking', weight: 25, skill: 'speaking' },
  { id: 'interview', title: 'AI Interview', weight: 15, skill: 'interview' },
  { id: 'review', title: 'Review', weight: 10, skill: 'review' },
] as const;

export function getDailyTasks(totalMinutes: number): DailyTask[] {
  const target = totalMinutes >= 150 ? 150 : totalMinutes;
  const weightTotal = TASK_WEIGHTS.reduce((sum, task) => sum + task.weight, 0);
  let assigned = 0;
  return TASK_WEIGHTS.map((task, index) => {
    const remaining = TASK_WEIGHTS.length - index - 1;
    const minutes =
      index === TASK_WEIGHTS.length - 1
        ? Math.max(2, target - assigned)
        : Math.max(2, Math.round((target * task.weight) / weightTotal));
    assigned += minutes;
    return {
      id: task.id,
      title: task.title,
      minutes: remaining === 0 ? Math.max(2, target - assigned + minutes) : minutes,
      skill: task.skill,
    };
  });
}

export type VocabularyWord = {
  id: string;
  word: string;
  definition: string;
  urdu: string;
  pronunciation: string;
  partOfSpeech: string;
  example: string;
  synonyms: string[];
  antonyms: string[];
  difficulty: string;
};

export const WORDS: VocabularyWord[] = [
  {
    id: 'reliable',
    word: 'reliable',
    definition: 'Able to be trusted or depended on.',
    urdu: 'قابلِ اعتماد',
    pronunciation: 'ri-LY-uh-bul',
    partOfSpeech: 'adjective',
    example: 'A reliable friend keeps a promise.',
    synonyms: ['dependable', 'trustworthy'],
    antonyms: ['unreliable', 'uncertain'],
    difficulty: 'Beginner',
  },
  {
    id: 'improve',
    word: 'improve',
    definition: 'To become better, or to make something better.',
    urdu: 'بہتر کرنا',
    pronunciation: 'im-PROOV',
    partOfSpeech: 'verb',
    example: 'She reads every evening to improve her English.',
    synonyms: ['develop', 'advance'],
    antonyms: ['worsen', 'decline'],
    difficulty: 'Beginner',
  },
  {
    id: 'curious',
    word: 'curious',
    definition: 'Eager to learn or know about something.',
    urdu: 'تجسس رکھنے والا',
    pronunciation: 'KYOOR-ee-us',
    partOfSpeech: 'adjective',
    example: 'The curious student asked a thoughtful question.',
    synonyms: ['interested', 'inquisitive'],
    antonyms: ['uninterested', 'indifferent'],
    difficulty: 'Beginner',
  },
  {
    id: 'prepare',
    word: 'prepare',
    definition: 'To get ready for something.',
    urdu: 'تیاری کرنا',
    pronunciation: 'pri-PAIR',
    partOfSpeech: 'verb',
    example: 'I prepare my notes before class.',
    synonyms: ['organize', 'plan'],
    antonyms: ['neglect', 'ignore'],
    difficulty: 'Beginner',
  },
  {
    id: 'confident',
    word: 'confident',
    definition: 'Feeling sure about your abilities or choices.',
    urdu: 'پُراعتماد',
    pronunciation: 'KON-fi-dent',
    partOfSpeech: 'adjective',
    example: 'Practice helped him feel confident in the interview.',
    synonyms: ['assured', 'self-reliant'],
    antonyms: ['uncertain', 'unsure'],
    difficulty: 'Beginner',
  },
  {
    id: 'opportunity',
    word: 'opportunity',
    definition: 'A good time or chance to do something.',
    urdu: 'موقع',
    pronunciation: 'op-er-TOO-ni-tee',
    partOfSpeech: 'noun',
    example: 'The course gave her an opportunity to practise speaking.',
    synonyms: ['chance', 'possibility'],
    antonyms: ['obstacle', 'setback'],
    difficulty: 'Elementary',
  },
  {
    id: 'achieve',
    word: 'achieve',
    definition: 'To succeed in doing or reaching something.',
    urdu: 'حاصل کرنا',
    pronunciation: 'uh-CHEEV',
    partOfSpeech: 'verb',
    example: 'He worked steadily to achieve his goal.',
    synonyms: ['accomplish', 'attain'],
    antonyms: ['fail', 'lose'],
    difficulty: 'Elementary',
  },
  {
    id: 'communicate',
    word: 'communicate',
    definition: 'To share information, ideas, or feelings.',
    urdu: 'بات چیت کرنا',
    pronunciation: 'kuh-MYOO-ni-kayt',
    partOfSpeech: 'verb',
    example: 'Clear examples help us communicate our ideas.',
    synonyms: ['express', 'share'],
    antonyms: ['conceal', 'withhold'],
    difficulty: 'Elementary',
  },
  {
    id: 'thoughtful',
    word: 'thoughtful',
    definition: 'Showing care by thinking about other people.',
    urdu: 'خیال رکھنے والا',
    pronunciation: 'THAWT-ful',
    partOfSpeech: 'adjective',
    example: 'It was thoughtful of Maya to help her new classmate.',
    synonyms: ['considerate', 'kind'],
    antonyms: ['careless', 'thoughtless'],
    difficulty: 'Elementary',
  },
  {
    id: 'abundant',
    word: 'abundant',
    definition: 'Existing in large amounts; more than enough.',
    urdu: 'بہت زیادہ',
    pronunciation: 'uh-BUN-dunt',
    partOfSpeech: 'adjective',
    example: 'The library has an abundant supply of study materials.',
    synonyms: ['plentiful', 'ample'],
    antonyms: ['scarce', 'limited'],
    difficulty: 'Intermediate',
  },
  {
    id: 'perspective',
    word: 'perspective',
    definition: 'A particular way of thinking about or understanding something.',
    urdu: 'نقطۂ نظر',
    pronunciation: 'per-SPEK-tiv',
    partOfSpeech: 'noun',
    example: 'Reading different accounts gave her a broader perspective.',
    synonyms: ['viewpoint', 'outlook'],
    antonyms: ['certainty', 'fact'],
    difficulty: 'Pre-Intermediate',
  },
  {
    id: 'contrast',
    word: 'contrast',
    definition: 'A clear difference between two things.',
    urdu: 'فرق',
    pronunciation: 'KON-trast',
    partOfSpeech: 'noun / verb',
    example: 'The report contrasts older and newer study methods.',
    synonyms: ['difference', 'distinction'],
    antonyms: ['similarity', 'agreement'],
    difficulty: 'Pre-Intermediate',
  },
  {
    id: 'sustainable',
    word: 'sustainable',
    definition: 'Able to continue for a long time without causing serious harm.',
    urdu: 'دیرپا',
    pronunciation: 'suh-STAY-nuh-bul',
    partOfSpeech: 'adjective',
    example: 'The team designed a sustainable plan for the community garden.',
    synonyms: ['lasting', 'renewable'],
    antonyms: ['temporary', 'wasteful'],
    difficulty: 'Intermediate',
  },
  {
    id: 'evaluate',
    word: 'evaluate',
    definition: 'To judge the value, quality, or importance of something.',
    urdu: 'جائزہ لینا',
    pronunciation: 'ih-VAL-yoo-ayt',
    partOfSpeech: 'verb',
    example: 'We evaluate each source before using it in an essay.',
    synonyms: ['assess', 'appraise'],
    antonyms: ['ignore', 'overlook'],
    difficulty: 'Intermediate',
  },
  {
    id: 'coherent',
    word: 'coherent',
    definition: 'Clear and logically connected.',
    urdu: 'منطقی اور واضح',
    pronunciation: 'koh-HEER-unt',
    partOfSpeech: 'adjective',
    example: 'A coherent paragraph presents its ideas in a clear order.',
    synonyms: ['logical', 'consistent'],
    antonyms: ['confusing', 'disjointed'],
    difficulty: 'Upper-Intermediate',
  },
  {
    id: 'facilitate',
    word: 'facilitate',
    definition: 'To make an action or process easier.',
    urdu: 'آسان بنانا',
    pronunciation: 'fuh-SIL-i-tayt',
    partOfSpeech: 'verb',
    example: 'Clear instructions facilitate independent study.',
    synonyms: ['enable', 'assist'],
    antonyms: ['hinder', 'obstruct'],
    difficulty: 'Upper-Intermediate',
  },
  {
    id: 'compelling',
    word: 'compelling',
    definition: 'Very convincing or interesting.',
    urdu: 'دلائل سے قائل کرنے والا',
    pronunciation: 'kum-PEL-ing',
    partOfSpeech: 'adjective',
    example: 'The researcher offered compelling evidence for the proposal.',
    synonyms: ['convincing', 'persuasive'],
    antonyms: ['unconvincing', 'weak'],
    difficulty: 'Advanced',
  },
  {
    id: 'nuanced',
    word: 'nuanced',
    definition: 'Showing small but meaningful differences or details.',
    urdu: 'باریک فرق کو سمجھنے والا',
    pronunciation: 'NOO-ahnst',
    partOfSpeech: 'adjective',
    example: 'Her nuanced answer considered both sides of the question.',
    synonyms: ['subtle', 'refined'],
    antonyms: ['simplistic', 'obvious'],
    difficulty: 'Advanced',
  },
  {
    id: 'articulate',
    word: 'articulate',
    definition: 'To express an idea clearly and effectively.',
    urdu: 'واضح طور پر بیان کرنا',
    pronunciation: 'ar-TIK-yuh-layt',
    partOfSpeech: 'verb',
    example: 'He learned to articulate his recommendations with confidence.',
    synonyms: ['express', 'communicate'],
    antonyms: ['mumble', 'obscure'],
    difficulty: 'Professional',
  },
  {
    id: 'pragmatic',
    word: 'pragmatic',
    definition: 'Focused on practical results and realistic choices.',
    urdu: 'عملی',
    pronunciation: 'prag-MAT-ik',
    partOfSpeech: 'adjective',
    example: 'The manager proposed a pragmatic solution to the scheduling problem.',
    synonyms: ['practical', 'realistic'],
    antonyms: ['impractical', 'idealistic'],
    difficulty: 'Professional',
  },
];

export type ReadingQuestion = {
  type: string;
  prompt: string;
  options: string[];
  answer: number;
  explanation: string;
};

export type ReadingPassage = {
  title: string;
  topic: string;
  level: number;
  text: string;
  questions: ReadingQuestion[];
};

export const PASSAGES: ReadingPassage[] = [
  {
    title: 'A Better Morning Routine',
    topic: 'Daily life',
    level: 1,
    text: 'Amina wanted to feel calm before class. She put her books and water bottle near the door each night. In the morning, she ate breakfast and checked her study plan. This small routine saved time. She still had a few busy mornings, but she felt more prepared during the week.',
    questions: [
      { type: 'Detail', prompt: 'What did Amina put near the door?', options: ['Her books and water bottle', 'Her shoes and coat', 'Her breakfast', 'Her phone charger'], answer: 0, explanation: 'The passage says she put her books and water bottle by the door.' },
      { type: 'Main idea', prompt: 'What is the passage mainly about?', options: ['How a small routine helped Amina prepare', 'Why classes start early', 'How to choose a water bottle', 'Where to buy books'], answer: 0, explanation: 'The details show how planning the night before made mornings easier.' },
      { type: 'Inference', prompt: 'Why did Amina prepare the night before?', options: ['To save time in the morning', 'To avoid going to class', 'To change her study plan', 'To eat breakfast later'], answer: 0, explanation: 'Preparing her things beforehand saved time.' },
    ],
  },
  {
    title: 'Learning Together',
    topic: 'Education',
    level: 2,
    text: 'At the community library, a group of learners meets every Thursday. They take turns explaining a new idea in simple words. When someone makes a mistake, the group asks a helpful question instead of interrupting. Members say the supportive routine makes it easier to speak and remember new information.',
    questions: [
      { type: 'True or false', prompt: 'The group meets once a week.', options: ['True', 'False', 'Not given'], answer: 0, explanation: 'They meet every Thursday, which is once a week.' },
      { type: 'Vocabulary', prompt: 'In this passage, “take turns” means…', options: ['Do something one after another', 'Leave the room quickly', 'Repeat the same task alone', 'Choose a different library'], answer: 0, explanation: 'Each learner explains an idea after another learner.' },
      { type: 'Main idea', prompt: 'Why does the routine help the learners?', options: ['It gives them a supportive way to practise', 'It makes every answer correct', 'It removes the need to study', 'It shortens the library hours'], answer: 0, explanation: 'The respectful group gives people room to practise and remember.' },
    ],
  },
  {
    title: 'A Greener Campus',
    topic: 'Science & society',
    level: 3,
    text: 'A university added refill stations beside its busiest lecture halls. The change did not solve every waste problem, but student surveys found that more people carried reusable bottles afterward. The facilities team also recorded fewer single-use cups in nearby bins. The university plans to compare the results over the next semester before expanding the programme.',
    questions: [
      { type: 'True, false, or not given', prompt: 'The refill stations eliminated all campus waste.', options: ['True', 'False', 'Not given'], answer: 1, explanation: 'The passage says the change did not solve every waste problem.' },
      { type: 'Detail', prompt: 'What did the facilities team notice?', options: ['Fewer single-use cups nearby', 'More lecture halls were built', 'The surveys were cancelled', 'Reusable bottles became unavailable'], answer: 0, explanation: 'They recorded fewer disposable cups in the nearby bins.' },
      { type: 'Inference', prompt: 'Why wait before expanding the programme?', options: ['To compare results over time', 'To remove all refill stations', 'To change the survey questions', 'To reduce the number of students'], answer: 0, explanation: 'The university wants more evidence from another semester.' },
    ],
  },
  {
    title: 'A More Flexible Workday',
    topic: 'Work & study',
    level: 4,
    text: 'A small design company tested flexible start times for three months. Employees could begin between seven and ten, as long as they attended a shared planning meeting. Managers tracked completed projects and asked staff about their energy. Output stayed steady, while many employees said the new schedule made commuting less stressful. The company will review the results before making the change permanent.',
    questions: [
      { type: 'Detail', prompt: 'What did employees need to attend together?', options: ['A shared planning meeting', 'A daily training course', 'A new commute survey', 'A weekend workshop'], answer: 0, explanation: 'The passage says staff could choose their start time but had to attend the shared planning meeting.' },
      { type: 'Vocabulary', prompt: 'Here, “steady” is closest in meaning to…', options: ['Consistent', 'Sudden', 'Uncertain', 'Unimportant'], answer: 0, explanation: 'Output stayed at a similar level during the trial, so “consistent” fits.' },
      { type: 'Inference', prompt: 'Why will the company review the results?', options: ['It has not yet decided to make the change permanent', 'It plans to remove the planning meeting', 'Employees asked to work only at night', 'The project output fell sharply'], answer: 0, explanation: 'The final sentence says the company will review the trial before deciding whether to keep the schedule.' },
    ],
  },
  {
    title: 'Repair, Reuse, Repeat',
    topic: 'Environment',
    level: 5,
    text: 'A neighbourhood repair café invites residents to bring small household items that no longer work. Volunteers with different skills help visitors diagnose the problem, and the owner decides whether to repair the item. The café does not accept every object, but its organisers say that teaching basic repair skills is as important as fixing things. They record which items are saved to understand what residents need.',
    questions: [
      { type: 'Detail', prompt: 'Who decides whether an item should be repaired?', options: ['The owner', 'The café organiser', 'The nearest shop', 'A city inspector'], answer: 0, explanation: 'The owner decides after volunteers help identify the problem.' },
      { type: 'Main idea', prompt: 'What is important to the organisers besides fixing objects?', options: ['Teaching basic repair skills', 'Selling replacement items', 'Collecting every household object', 'Reducing volunteer hours'], answer: 0, explanation: 'The passage says repair skills are as important as the repairs themselves.' },
      { type: 'Inference', prompt: 'Why do organisers record saved items?', options: ['To learn what residents need', 'To decide who may enter the café', 'To charge people for each repair', 'To stop volunteers sharing skills'], answer: 0, explanation: 'The last sentence links the records to understanding residents’ needs.' },
    ],
  },
  {
    title: 'Reading the Evidence',
    topic: 'Research',
    level: 6,
    text: 'A research team compared two groups of students who used different revision schedules. At the end of the term, one group remembered more details on a short test. The team cautioned that the groups also differed in how many practice questions they completed. Because several factors changed at once, the results could not show that the schedule alone caused the difference. A controlled follow-up study is planned.',
    questions: [
      { type: 'Detail', prompt: 'What other difference between the groups did the researchers note?', options: ['The number of practice questions', 'The length of the school term', 'The subject of the short test', 'The rooms used for revision'], answer: 0, explanation: 'The groups differed in the number of practice questions they completed.' },
      { type: 'Inference', prompt: 'Why could the team not attribute the result to the schedule alone?', options: ['More than one factor varied between the groups', 'Students did not take the test', 'The term ended before the study began', 'Both groups used the same schedule'], answer: 0, explanation: 'The researchers say several factors changed at once.' },
      { type: 'Purpose', prompt: 'What is the purpose of a controlled follow-up study?', options: ['To test the schedule while controlling other factors', 'To replace the original students', 'To avoid collecting new evidence', 'To shorten the term'], answer: 0, explanation: 'A controlled study can better isolate the effect of the revision schedule.' },
    ],
  },
  {
    title: 'Designing for a Changing City',
    topic: 'Cities & society',
    level: 7,
    text: 'When the riverside district planned new public spaces, its design team held workshops with residents, shop owners and transport staff. Early proposals included a wide paved plaza, but residents asked for shade and places to sit. The revised plan added trees, benches and a smaller performance area. The team also kept one section open for future changes, arguing that public spaces should adapt as the neighbourhood does.',
    questions: [
      { type: 'Detail', prompt: 'What did residents ask to add to the early proposal?', options: ['Shade and places to sit', 'A larger paved area', 'More private offices', 'A permanent market hall'], answer: 0, explanation: 'Residents asked for shade and places to sit.' },
      { type: 'Purpose', prompt: 'Why did the plan keep one section open for changes?', options: ['The neighbourhood’s needs may change', 'The workshops were cancelled', 'The team did not consult residents', 'The plaza needed more paving'], answer: 0, explanation: 'The team argues that public spaces should adapt as the area changes.' },
      { type: 'Inference', prompt: 'What does the workshop process suggest about the team?', options: ['It considered feedback from several groups', 'It followed its first design without revision', 'It focused only on transport staff', 'It planned a private space'], answer: 0, explanation: 'The revised plan reflects requests made during workshops.' },
    ],
  },
  {
    title: 'The Value of a Public Library',
    topic: 'Education & culture',
    level: 8,
    text: 'As more information moves online, some cities have reconsidered the role of public libraries. Their value is not measured only by the number of books borrowed. Libraries can provide quiet study areas, reliable internet access and staff who help visitors evaluate sources. These services matter most to people without suitable space or equipment at home. A recent city review recommended testing extended opening hours in districts where residents reported the greatest need, then comparing usage and feedback before expanding the programme.',
    questions: [
      { type: 'Main idea', prompt: 'What is the passage mainly arguing?', options: ['Libraries offer several useful services beyond lending books', 'All library services should move online', 'Borrowing totals are the only useful measure', 'Every district needs identical opening hours'], answer: 0, explanation: 'The passage lists study space, internet and help evaluating information as important library services.' },
      { type: 'Vocabulary', prompt: 'In this passage, “evaluate sources” means…', options: ['Judge how useful and trustworthy information is', 'Copy every article into a notebook', 'Avoid reading online material', 'Borrow books without checking them'], answer: 0, explanation: 'Evaluating a source means assessing its quality and trustworthiness.' },
      { type: 'Inference', prompt: 'Why test longer hours in selected districts first?', options: ['To compare use and feedback before expanding', 'To reduce access where need is greatest', 'To replace library staff with internet access', 'To avoid listening to residents'], answer: 0, explanation: 'The review recommends a limited test and comparison before broader expansion.' },
    ],
  },
];

export type GrammarTopic = {
  title: string;
  level: number;
  rule: string;
  example: string;
  prompt: string;
  options: string[];
  answer: number;
  correction: string;
  practice: string;
};

export const GRAMMAR_TOPICS: GrammarTopic[] = [
  { title: 'Pronouns', level: 1, rule: 'Use a subject pronoun before the main verb.', example: 'She studies every day.', prompt: '___ are learning English.', options: ['We', 'Us', 'Our', 'Ours'], answer: 0, correction: 'Use “we” as the subject.', practice: 'Write one sentence that begins with “They”.' },
  { title: 'Nouns & plurals', level: 1, rule: 'Add -s to most regular nouns to make them plural.', example: 'one lesson → two lessons', prompt: 'I have three ___.', options: ['book', 'books', 'bookes', 'booking'], answer: 1, correction: 'Use the plural noun “books”.', practice: 'Write the plural form of “class”.' },
  { title: 'Articles', level: 1, rule: 'Use “a” before a consonant sound and “an” before a vowel sound.', example: 'a lesson · an exercise', prompt: 'She reads ___ interesting story.', options: ['a', 'an', 'the a', 'no article'], answer: 1, correction: '“Interesting” begins with a vowel sound, so use “an”.', practice: 'Write one example with “a” and one with “an”.' },
  { title: 'Verb to be', level: 1, rule: 'Match am, is, or are to the subject.', example: 'I am ready. He is ready. They are ready.', prompt: 'My friends ___ helpful.', options: ['am', 'is', 'are', 'be'], answer: 2, correction: '“Friends” is plural, so use “are”.', practice: 'Complete: “My teacher ___ kind.”' },
  { title: 'Present Simple', level: 1, rule: 'Use the base verb with I/you/we/they. Add -s with he/she/it.', example: 'I practise. She practises.', prompt: 'He ___ English after class.', options: ['study', 'studies', 'studying', 'studied'], answer: 1, correction: 'With “he”, use the third-person form “studies”.', practice: 'Write one sentence about a daily habit.' },
  { title: 'Past Simple', level: 1, rule: 'Use the past form for a completed action.', example: 'We visited the library yesterday.', prompt: 'They ___ the lesson yesterday.', options: ['finish', 'finishes', 'finished', 'finishing'], answer: 2, correction: '“Yesterday” signals the past; use “finished”.', practice: 'Write one sentence about what you learned yesterday.' },
  { title: 'Future with will', level: 1, rule: 'Use will + base verb for a future decision or prediction.', example: 'I will review these words tonight.', prompt: 'She will ___ the new topic tomorrow.', options: ['study', 'studies', 'studied', 'studying'], answer: 0, correction: 'After “will”, use the base verb “study”.', practice: 'Write one plan for tomorrow.' },
  { title: 'Prepositions', level: 2, rule: 'Use common prepositions to show time, place, and direction.', example: 'at 8 · in the room · on Monday', prompt: 'The class starts ___ Monday.', options: ['in', 'on', 'at', 'to'], answer: 1, correction: 'Use “on” with days of the week.', practice: 'Write a sentence with “at” and a time.' },
  { title: 'Present Continuous', level: 3, rule: 'Use am/is/are + verb-ing for an action happening now.', example: 'They are reading now.', prompt: 'I ___ a new passage right now.', options: ['read', 'am reading', 'reads', 'have read'], answer: 1, correction: 'Use “am” + “reading” for an action happening now.', practice: 'Describe what you are doing at this moment.' },
  { title: 'Present Perfect', level: 4, rule: 'Use have/has + past participle for experience or a past action connected to now.', example: 'She has completed two units.', prompt: 'We ___ this grammar rule before.', options: ['study', 'studied', 'have studied', 'are study'], answer: 2, correction: 'Use “have” + past participle “studied”.', practice: 'Write one thing you have learned this month.' },
  { title: 'Conditionals', level: 5, rule: 'Use if + present simple, will + base verb for a real future possibility.', example: 'If I practise, I will improve.', prompt: 'If he reviews today, he ___ remember the words.', options: ['will', 'would', 'has', 'was'], answer: 0, correction: 'Use “will” for the result of a real future condition.', practice: 'Finish: “If I have time, I will…”' },
  { title: 'Passive voice', level: 6, rule: 'Use be + past participle when the action matters more than the doer.', example: 'The report was written yesterday.', prompt: 'The results ___ every month.', options: ['review', 'are reviewed', 'reviewing', 'has review'], answer: 1, correction: 'Use “are” + past participle “reviewed”.', practice: 'Rewrite a sentence so the object becomes the subject.' },
  { title: 'Hedging claims', level: 7, rule: 'Use cautious language such as may, can, or appears to when evidence does not support certainty.', example: 'The results may indicate a useful trend.', prompt: 'Choose the most careful academic claim.', options: ['This proves the method always works.', 'The results may suggest a useful pattern.', 'Everyone must accept the method.', 'The method has no possible limits.'], answer: 1, correction: '“May suggest” reports a possible interpretation without claiming certainty.', practice: 'Rewrite an absolute claim using cautious language.' },
  { title: 'Parallel structure', level: 8, rule: 'Use the same grammatical form for items in a list or paired ideas.', example: 'The course develops reading, writing, and speaking.', prompt: 'Which sentence uses parallel structure?', options: ['The course helps learners read, writing, and to speak.', 'The course helps learners reading, write, and speak.', 'The course helps learners read, write, and speak.', 'The course helps learners to read, writing, and speak.'], answer: 2, correction: 'Keep all three verbs in the same base form: read, write, speak.', practice: 'Write a sentence with three parallel study goals.' },
];

export const WRITING_PROMPTS = [
  'Write 3–5 sentences about a skill you want to improve.',
  'Write a short email asking a teacher for advice.',
  'Give your opinion: should students study in groups? Explain why.',
  'Describe a useful change in technology and its effect on daily life.',
];

export const FIRST_INTERVIEW_QUESTIONS: Record<number, string[]> = {
  1: ['What is your name, and what do you enjoy doing?'],
  2: ['Can you tell me about your daily routine?'],
  3: ['What subject do you enjoy studying, and why?'],
  4: ['Tell me about a goal you are working toward.'],
  5: ['What experience has taught you an important lesson?'],
  6: ['How is technology changing the way people learn?'],
  7: ['What makes a community a good place to live?'],
  8: ['How should professionals communicate when they disagree?'],
};

export function getTodayKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function average(values: number[]): number {
  return values.length ? Math.round(values.reduce((sum, value) => sum + value, 0) / values.length) : 0;
}

export function placementLevel(score: number): number {
  if (score >= 92) return 8;
  if (score >= 84) return 7;
  if (score >= 76) return 6;
  if (score >= 68) return 5;
  if (score >= 60) return 4;
  if (score >= 50) return 3;
  if (score >= 38) return 2;
  return 1;
}

export function currentStreak(studyDays: string[]): number {
  const days = new Set(studyDays);
  let date = new Date();
  const today = getTodayKey();
  if (!days.has(today)) {
    date.setDate(date.getDate() - 1);
    if (!days.has(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`)) return 0;
  }
  let count = 0;
  while (true) {
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    if (!days.has(key)) break;
    count += 1;
    date.setDate(date.getDate() - 1);
  }
  return count;
}