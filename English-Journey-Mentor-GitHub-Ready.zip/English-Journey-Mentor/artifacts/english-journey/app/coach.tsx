import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import React, { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Banner, IconButton, SmallHeader } from '@/components/ui';
import { useLearning, type ChatEntry } from '@/context/LearningContext';
import { getNetworkMessage, useLearningAI } from '@/hooks/useLearningAI';
import { useColors } from '@/hooks/useColors';

function ChatBubble({ message }: { message: ChatEntry }) {
  const colors = useColors();
  const mine = message.role === 'user';
  return (
    <View style={{ alignItems: mine ? 'flex-end' : 'flex-start', marginBottom: 10 }}>
      <View style={{
        maxWidth: '88%',
        paddingHorizontal: 13,
        paddingVertical: 10,
        borderRadius: 17,
        borderBottomRightRadius: mine ? 5 : 17,
        borderBottomLeftRadius: mine ? 17 : 5,
        backgroundColor: mine ? colors.primary : colors.card,
        borderWidth: mine ? 0 : 1,
        borderColor: colors.border,
      }}>
        <Text style={{ color: mine ? colors.primaryForeground : colors.foreground, fontSize: 13, lineHeight: 20 }}>{message.text}</Text>
        <Text style={{ color: mine ? colors.primaryForeground : colors.mutedForeground, opacity: mine ? 0.76 : 1, fontSize: 9, marginTop: 4 }}>
          {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </View>
  );
}

export default function CoachScreen() {
  const { state, addChatMessage, clearChatMessages } = useLearning();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { askCoach, busy } = useLearningAI();
  const [draft, setDraft] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [lastMessage, setLastMessage] = useState<string>('');
  const level = state.profile?.level ?? 1;

  const send = async (input = draft, addUserMessage = true) => {
    const cleanMessage = input.trim();
    if (!cleanMessage || busy) return;
    setError(null);
    setLastMessage(cleanMessage);
    if (addUserMessage) {
      addChatMessage('user', cleanMessage);
      setDraft('');
    }
    const contextMessages = addUserMessage
      ? [...state.chatMessages, { role: 'user' as const, text: cleanMessage }]
      : state.chatMessages;
    const context = contextMessages
      .slice(-8)
      .map((message) => `${message.role === 'user' ? 'Learner' : 'Coach'}: ${message.text.slice(0, 420)}`)
      .join('\n')
      .slice(-3700);
    try {
      const result = await askCoach('chat', cleanMessage, level, context);
      const reply = [result.feedback, ...result.corrections.map((item) => `• ${item}`)].filter(Boolean).join('\n\n');
      addChatMessage('assistant', reply || 'Tell me a little more about what you would like help with.');
    } catch (cause) {
      setError(getNetworkMessage(cause));
    }
  };

  const clearChat = () => {
    Alert.alert('Clear coach chat?', 'This removes the saved messages from this device.', [
      { text: 'Keep chat', style: 'cancel' },
      { text: 'Clear chat', style: 'destructive', onPress: () => {
        clearChatMessages();
        setError(null);
      } },
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }} edges={['top', 'left', 'right']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={0}>
        <View style={{ paddingHorizontal: 14, borderBottomWidth: 1, borderBottomColor: colors.border }}>
          <SmallHeader
            title="English coach"
            back={() => router.back()}
            action={<IconButton icon="more-horizontal" label="Chat options" onPress={clearChat} />}
          />
        </View>
        <View style={{ flex: 1 }}>
          <FlatList
            inverted
            data={[...state.chatMessages].reverse()}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <ChatBubble message={item} />}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{ paddingHorizontal: 15, paddingTop: 14, paddingBottom: 14, flexGrow: 1 }}
            ListEmptyComponent={
              <View style={{ alignItems: 'center', justifyContent: 'center', paddingHorizontal: 22, paddingVertical: 28 }}>
                <View style={{ width: 54, height: 54, alignItems: 'center', justifyContent: 'center', borderRadius: 19, backgroundColor: colors.blueSoft }}>
                  <Feather name="message-circle" size={25} color={colors.primary} />
                </View>
                <Text style={{ color: colors.foreground, fontSize: 17, fontWeight: '800', textAlign: 'center', marginTop: 12 }}>What would you like to practise?</Text>
                <Text style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18, textAlign: 'center', marginTop: 5 }}>Ask a grammar question, get a sentence correction, or practise a conversation at your level.</Text>
              </View>
            }
          />
          {busy ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, paddingVertical: 8 }}>
              <ActivityIndicator size="small" color={colors.primary} />
              <Text style={{ color: colors.mutedForeground, fontSize: 11 }}>Your coach is thinking…</Text>
            </View>
          ) : null}
        </View>
        {error ? (
          <View style={{ paddingHorizontal: 12 }}>
            <Banner icon="wifi-off" title="Coach could not reply" body={error} tone="orange" />
            <Pressable accessibilityRole="button" disabled={busy} onPress={() => send(lastMessage, false)} style={{ marginTop: -7, marginBottom: 7, paddingLeft: 13 }}>
              <Text style={{ color: colors.primary, fontSize: 12, fontWeight: '700' }}>Retry response</Text>
            </Pressable>
          </View>
        ) : null}
        <View style={{
          flexDirection: 'row',
          alignItems: 'flex-end',
          gap: 8,
          borderTopWidth: 1,
          borderTopColor: colors.border,
          backgroundColor: colors.card,
          paddingHorizontal: 12,
          paddingTop: 10,
          paddingBottom: Math.max(insets.bottom, 9),
        }}>
          <TextInput
            value={draft}
            onChangeText={setDraft}
            placeholder="Ask your English coach…"
            placeholderTextColor={colors.mutedForeground}
            multiline
            maxLength={2000}
            returnKeyType="send"
            blurOnSubmit
            onSubmitEditing={() => void send()}
            accessibilityLabel="Message your English coach"
            style={{
              flex: 1,
              maxHeight: 120,
              minHeight: 44,
              borderRadius: 15,
              borderWidth: 1,
              borderColor: colors.border,
              backgroundColor: colors.background,
              color: colors.foreground,
              paddingHorizontal: 13,
              paddingTop: 11,
              paddingBottom: 9,
              fontSize: 13,
            }}
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Send message"
            accessibilityState={{ disabled: !draft.trim() || busy }}
            disabled={!draft.trim() || busy}
            onPress={() => void send()}
            style={({ pressed }) => ({
              width: 44,
              height: 44,
              borderRadius: 15,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: !draft.trim() || busy ? colors.muted : colors.primary,
              opacity: pressed ? 0.75 : 1,
            })}
          >
            {busy ? <ActivityIndicator size="small" color={colors.primaryForeground} /> : <Feather name="arrow-up" size={19} color={colors.primaryForeground} />}
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}