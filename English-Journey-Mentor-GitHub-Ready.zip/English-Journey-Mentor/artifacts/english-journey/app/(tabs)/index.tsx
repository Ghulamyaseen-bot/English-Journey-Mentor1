import { Feather } from '@expo/vector-icons';
import { Redirect, router } from 'expo-router';
import React from 'react';
import { ActivityIndicator, Pressable, Text, View } from 'react-native';
import {
  ActionButton,
  Avatar,
  Banner,
  Card,
  Heading,
  HeaderGradient,
  MetricCard,
  Page,
  ProgressBar,
  ProgressRing,
} from '@/components/ui';
import { learningColors } from '@/constants/colors';
import {
  average,
  currentStreak,
  getDailyTasks,
  getTodayKey,
  LEVELS,
  SKILLS,
} from '@/constants/learning';
import { useLearning } from '@/context/LearningContext';
import { useColors } from '@/hooks/useColors';

const skillIcons = {
  vocabulary: 'book',
  reading: 'book-open',
  writing: 'edit-3',
  speaking: 'mic',
  grammar: 'layers',
  interview: 'message-circle',
} as const;

const skillRoutes = {
  vocabulary: '/(tabs)/practice',
  reading: '/(tabs)/practice',
  writing: '/(tabs)/practice',
  speaking: '/(tabs)/speak',
  grammar: '/(tabs)/practice',
  interview: '/(tabs)/interview',
  review: '/(tabs)/practice',
} as const;

export default function HomeScreen() {
  const { state, ready } = useLearning();
  const colors = useColors();
  if (!ready) {
    return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}><ActivityIndicator color={colors.primary} /></View>;
  }
  if (!state.profile) return <Redirect href="/" />;

  const profile = state.profile;
  const today = getTodayKey();
  const todayTasks = getDailyTasks(profile.studyMinutes);
  const doneToday = state.completedByDate[today] ?? [];
  const planProgress = Math.round((doneToday.length / todayTasks.length) * 100);
  const streak = currentStreak(state.studyDays);
  const learnedWords = Object.values(state.wordMemory).filter((item) => item.correct >= 2).length;
  const reviewWords = Object.values(state.wordMemory).filter((item) => item.incorrect > item.correct).length;
  const scoreValues = Object.values(state.scores);
  const overallScore = average(scoreValues.filter((score) => score > 0));
  const scoredSkills = SKILLS.filter((skill) => state.scores[skill.id] > 0);
  const lowest = [...scoredSkills].sort((a, b) => state.scores[a.id] - state.scores[b.id])[0];
  const highest = [...scoredSkills].sort((a, b) => state.scores[b.id] - state.scores[a.id])[0];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <Page padded={false}>
      <HeaderGradient>
        <View style={{ paddingHorizontal: 18, paddingTop: 9, paddingBottom: 26 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <View style={{ flex: 1, paddingRight: 10 }}>
              <Text style={{ color: colors.primaryForeground, opacity: 0.82, fontSize: 12, fontWeight: '600' }}>ENGLISH JOURNEY · LEVEL {profile.level}</Text>
              <Text numberOfLines={1} style={{ color: colors.primaryForeground, fontSize: 23, fontWeight: '800', marginTop: 5 }}>{greeting}, {profile.name}</Text>
              <Text style={{ color: colors.primaryForeground, opacity: 0.84, fontSize: 12, marginTop: 4 }}>Your daily practice is ready.</Text>
            </View>
            <Pressable accessibilityRole="button" accessibilityLabel="Open your profile" onPress={() => router.navigate('/(tabs)/profile')}>
              <Avatar size={52} />
            </Pressable>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 7, marginTop: 16 }}>
            <Feather name="calendar" size={13} color={colors.primaryForeground} />
            <Text style={{ color: colors.primaryForeground, opacity: 0.84, fontSize: 11 }}>
              {new Date().toLocaleDateString('en', { weekday: 'long', month: 'short', day: 'numeric' })}
            </Text>
            <View style={{ marginLeft: 'auto', flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Feather name="zap" size={14} color={colors.warning} />
              <Text style={{ color: colors.primaryForeground, fontSize: 12, fontWeight: '700' }}>{streak} day streak</Text>
            </View>
          </View>
        </View>
      </HeaderGradient>

      <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
        <Card style={{ marginTop: -21 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <ProgressRing value={overallScore} size={88} />
            <View style={{ flex: 1 }}>
              <Text style={{ color: colors.mutedForeground, fontSize: 11, fontWeight: '700', letterSpacing: 0.8 }}>YOUR CURRENT LEVEL</Text>
              <Text style={{ color: colors.foreground, fontSize: 18, fontWeight: '800', marginTop: 4 }}>Level {profile.level} of 8</Text>
              <Text style={{ color: colors.mutedForeground, fontSize: 12, marginTop: 3 }}>{LEVELS[profile.level - 1]}</Text>
              <ProgressBar value={overallScore} color={colors.teal} />
            </View>
          </View>
          {state.assessmentHistory.length === 0 ? (
            <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 16, marginTop: 11 }}>
              Take your first check-in to get a skill score and confirm your starting level.
            </Text>
          ) : null}
        </Card>

        {state.assessmentHistory.length === 0 ? (
          <Card style={{ backgroundColor: colors.blueSoft, borderColor: colors.blueSoft, padding: 14 }}>
            <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>
              <View style={{ width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.card }}>
                <Feather name="clipboard" size={17} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ color: colors.foreground, fontSize: 14, fontWeight: '800' }}>Start with a six-skill check-in</Text>
                <Text style={{ color: colors.mutedForeground, fontSize: 11, lineHeight: 16, marginTop: 4 }}>A short vocabulary, grammar, reading, writing, speaking and interview assessment sets your pace.</Text>
              </View>
            </View>
            <ActionButton title="Take my assessment" icon="arrow-right" onPress={() => router.push('/assessment')} style={{ marginTop: 12 }} />
          </Card>
        ) : null}

        <View style={{ flexDirection: 'row', gap: 9, marginBottom: 3 }}>
          <MetricCard label="Study time" value={`${state.totalStudyMinutes}m`} icon="clock" color={colors.primary} onPress={() => router.navigate('/(tabs)/progress')} />
          <MetricCard label="Words learned" value={`${learnedWords}`} icon="book" color={learningColors.vocabulary} onPress={() => router.navigate('/(tabs)/learn')} />
          <MetricCard label="Review words" value={`${reviewWords}`} icon="rotate-ccw" color={colors.warning} onPress={() => router.navigate('/(tabs)/practice')} />
        </View>

        <Heading
          eyebrow="Your daily plan"
          title="Small steps, steady progress"
          subtitle={`${doneToday.length} of ${todayTasks.length} activities complete · ${profile.studyMinutes}+ minutes set aside`}
          right={<View style={{ minWidth: 58, alignItems: 'flex-end' }}><Text style={{ color: colors.primary, fontSize: 16, fontWeight: '800' }}>{planProgress}%</Text></View>}
        />
        <Card style={{ paddingVertical: 7 }}>
          {todayTasks.map((task) => {
            const done = doneToday.includes(task.id);
            const icon = task.skill === 'review' ? 'rotate-ccw' : skillIcons[task.skill];
            const color = task.skill === 'review' ? colors.warning : learningColors[task.skill];
            return (
              <Pressable
                key={task.id}
                accessibilityRole="button"
                accessibilityLabel={`${task.title}, ${task.minutes} minutes${done ? ', complete' : ''}`}
                onPress={() => router.navigate(skillRoutes[task.skill])}
                style={({ pressed }) => [{ minHeight: 45, flexDirection: 'row', alignItems: 'center', gap: 10, opacity: pressed ? 0.7 : 1 }]}
              >
                <View style={{ width: 28, height: 28, borderRadius: 10, backgroundColor: done ? colors.successSoft : colors.secondary, alignItems: 'center', justifyContent: 'center' }}>
                  <Feather name={done ? 'check' : icon} size={14} color={done ? colors.success : color} />
                </View>
                <Text style={{ flex: 1, color: done ? colors.mutedForeground : colors.foreground, fontSize: 12, fontWeight: '700' }}>{task.title}</Text>
                <Text style={{ color: colors.mutedForeground, fontSize: 10 }}>{task.minutes} min</Text>
                {done ? <Feather name="check-circle" size={15} color={colors.success} /> : <Feather name="chevron-right" size={16} color={colors.mutedForeground} />}
              </Pressable>
            );
          })}
        </Card>

        <Heading eyebrow="Skill snapshot" title="What you're practising" subtitle="Scores update as you complete lessons and assessments." />
        {scoredSkills.length > 0 ? (
          <Card>
            {SKILLS.map((skill) => (
              <View key={skill.id} style={{ marginBottom: 13 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                  <Text style={{ color: colors.foreground, fontSize: 12, fontWeight: '600' }}>{skill.label}</Text>
                  <Text style={{ color: colors.mutedForeground, fontSize: 11 }}>{state.scores[skill.id] ? `${state.scores[skill.id]}%` : 'Not checked yet'}</Text>
                </View>
                <ProgressBar value={state.scores[skill.id]} color={learningColors[skill.id]} />
              </View>
            ))}
            {lowest && highest ? (
              <Banner
                icon="target"
                tone="orange"
                title={`Next focus: ${lowest.label}`}
                body={lowest.id === highest.id ? 'Keep practising every skill to build a balanced foundation.' : `${highest.label} is your strongest area right now. Keep it active while you build ${lowest.label.toLowerCase()}.`}
              />
            ) : null}
          </Card>
        ) : (
          <Card>
            <Text style={{ color: colors.foreground, fontSize: 13, fontWeight: '700' }}>Your strengths will show up here</Text>
            <Text style={{ color: colors.mutedForeground, fontSize: 12, lineHeight: 18, marginTop: 5 }}>Complete a lesson or the first check-in to see your skill scores and a useful next focus.</Text>
          </Card>
        )}

        <Heading eyebrow="Quick start" title="Keep your momentum" />
        <View style={{ gap: 9, marginBottom: 18 }}>
          <ActionButton title="Browse learning modules" icon="book-open" variant="secondary" onPress={() => router.navigate('/(tabs)/learn')} />
          <ActionButton title="Ask the AI English coach" icon="message-circle" variant="outline" onPress={() => router.push('/coach')} />
        </View>
      </View>
    </Page>
  );
}