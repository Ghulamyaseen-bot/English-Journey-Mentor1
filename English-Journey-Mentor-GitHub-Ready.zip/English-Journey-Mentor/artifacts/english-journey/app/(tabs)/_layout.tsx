import { Feather } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

function JourneyTabBar({ state, descriptors, navigation }: any) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <View
      style={[
        styles.tabBar,
        {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
          paddingBottom: Math.max(insets.bottom, 6),
        },
      ]}
    >
      {state.routes.map((route: { key: string; name: string; params?: unknown }, index: number) => {
        const options = descriptors[route.key]?.options;
        const focused = state.index === index;
        const label = typeof options?.tabBarLabel === 'string'
          ? options.tabBarLabel
          : options?.title ?? route.name;
        const color = focused ? colors.primary : colors.mutedForeground;
        const icon = options?.tabBarIcon?.({ focused, color, size: 18 });
        return (
          <Pressable
            key={route.key}
            accessibilityRole="tab"
            accessibilityState={{ selected: focused }}
            accessibilityLabel={String(label)}
            onPress={() => {
              const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
              if (!focused && !event.defaultPrevented) {
                navigation.navigate(route.name, route.params);
              }
            }}
            style={({ pressed }) => [styles.tabItem, { opacity: pressed ? 0.65 : 1 }]}
          >
            <View style={[styles.iconWrap, focused && { backgroundColor: colors.accent }]}>
              {icon ?? <Feather name="circle" size={18} color={color} />}
            </View>
            <Text numberOfLines={1} style={[styles.tabLabel, { color, fontWeight: focused ? '700' : '500' }]}>
              {label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export default function TabLayout() {
  const colors = useColors();
  return (
    <Tabs
      tabBar={(props) => <JourneyTabBar {...props} />}
      screenOptions={{ headerShown: false, sceneStyle: { backgroundColor: colors.background } }}
    >
      <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: ({ color, size }) => <Feather name="home" size={size} color={color} /> }} />
      <Tabs.Screen name="learn" options={{ title: 'Learn', tabBarIcon: ({ color, size }) => <Feather name="book-open" size={size} color={color} /> }} />
      <Tabs.Screen name="practice" options={{ title: 'Practice', tabBarIcon: ({ color, size }) => <Feather name="target" size={size} color={color} /> }} />
      <Tabs.Screen name="speak" options={{ title: 'Speak', tabBarIcon: ({ color, size }) => <Feather name="mic" size={size} color={color} /> }} />
      <Tabs.Screen name="interview" options={{ title: 'Interview', tabBarIcon: ({ color, size }) => <Feather name="message-circle" size={size} color={color} /> }} />
      <Tabs.Screen name="progress" options={{ title: 'Progress', tabBarIcon: ({ color, size }) => <Feather name="bar-chart-2" size={size} color={color} /> }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: ({ color, size }) => <Feather name="user" size={size} color={color} /> }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    minHeight: 61,
    borderTopWidth: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingTop: 4,
    elevation: 12,
  },
  tabItem: { flex: 1, minWidth: 0, minHeight: 52, alignItems: 'center', justifyContent: 'center', gap: 1 },
  iconWrap: { width: 34, height: 29, alignItems: 'center', justifyContent: 'center', borderRadius: 12 },
  tabLabel: { fontSize: 8, maxWidth: '100%', textAlign: 'center' },
});