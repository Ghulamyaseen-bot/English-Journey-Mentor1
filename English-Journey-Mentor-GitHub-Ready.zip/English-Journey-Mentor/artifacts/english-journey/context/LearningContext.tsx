import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { average, getTodayKey, placementLevel, type SkillKey } from '@/constants/learning';

export type LearnerProfile = {
  name: string;
  level: number;
  reportedLevel: number;
  studyMinutes: number;
  goal: string;
  ieltsGoal: string;
};

export type SkillScores = Record<SkillKey, number>;
export type ChatEntry = { id: string; role: 'user' | 'assistant'; text: string; createdAt: string };
export type WordRecord = { seen: number; correct: number; incorrect: number; lastSeen: string };
export type WritingSubmission = {
  id: string;
  date: string;
  prompt?: string;
  text: string;
  score: number;
  feedback: string;
  status?: 'draft' | 'reviewed';
};
export type InterviewTurn = { id: string; date: string; question: string; answer: string; feedback: string; score: number };
export type AssessmentRecord = { date: string; scores: SkillScores; overall: number };

export type LearningState = {
  profile: LearnerProfile | null;
  completedByDate: Record<string, string[]>;
  wordMemory: Record<string, WordRecord>;
  scores: SkillScores;
  assessmentHistory: AssessmentRecord[];
  mistakeMemory: string[];
  studyDays: string[];
  totalStudyMinutes: number;
  chatMessages: ChatEntry[];
  interviewQuestions: string[];
  interviewHistory: InterviewTurn[];
  writingSubmissions: WritingSubmission[];
  readingWordsPerMinute: number;
};

const STORAGE_KEY = 'english-journey.progress.v1';

export const emptyLearningState: LearningState = {
  profile: null,
  completedByDate: {},
  wordMemory: {},
  scores: { vocabulary: 0, reading: 0, writing: 0, speaking: 0, grammar: 0, interview: 0 },
  assessmentHistory: [],
  mistakeMemory: [],
  studyDays: [],
  totalStudyMinutes: 0,
  chatMessages: [],
  interviewQuestions: [],
  interviewHistory: [],
  writingSubmissions: [],
  readingWordsPerMinute: 0,
};

type LearningContextValue = {
  state: LearningState;
  ready: boolean;
  storageError: boolean;
  saveProfile: (profile: LearnerProfile) => void;
  updateProfile: (updates: Partial<LearnerProfile>) => void;
  completeActivity: (activityId: string, minutes: number, skill?: SkillKey, score?: number, wordsPerMinute?: number) => void;
  recordWordAnswer: (wordId: string, correct: boolean) => void;
  rememberMistake: (mistake: string) => void;
  resolveMistakeAt: (index: number) => void;
  addChatMessage: (role: ChatEntry['role'], text: string) => void;
  rememberInterviewQuestion: (question: string) => void;
  saveInterviewTurn: (question: string, answer: string, feedback: string, score: number) => void;
  saveWritingDraft: (prompt: string, text: string) => void;
  saveWritingSubmission: (prompt: string, text: string, score: number, feedback: string) => void;
  clearChatMessages: () => void;
  finishAssessment: (scores: SkillScores) => { placedLevel: number; promoted: boolean };
  resetProgress: () => void;
};

const LearningContext = createContext<LearningContextValue | null>(null);

export function LearningProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<LearningState>(emptyLearningState);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState(false);
  const stateRef = useRef<LearningState>(emptyLearningState);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!active) return;
        if (raw) {
          const parsed = JSON.parse(raw) as Partial<LearningState>;
          const restored = { ...emptyLearningState, ...parsed };
          stateRef.current = restored;
          setState(restored);
        }
      })
      .catch(() => {
        if (active) setStorageError(true);
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  const update = useCallback((change: (current: LearningState) => LearningState) => {
    const next = change(stateRef.current);
    stateRef.current = next;
    setState(next);
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)).catch(() => setStorageError(true));
  }, []);

  const saveProfile = useCallback((profile: LearnerProfile) => {
    update((current) => ({ ...current, profile }));
  }, [update]);

  const updateProfile = useCallback((updates: Partial<LearnerProfile>) => {
    update((current) => current.profile ? { ...current, profile: { ...current.profile, ...updates } } : current);
  }, [update]);

  const completeActivity = useCallback((activityId: string, minutes: number, skill?: SkillKey, score?: number, wordsPerMinute?: number) => {
    const today = getTodayKey();
    update((current) => {
      const completedToday = current.completedByDate[today] ?? [];
      const alreadyDone = completedToday.includes(activityId);
      const nextCompleted = alreadyDone ? completedToday : [...completedToday, activityId];
      const nextScores = skill && score !== undefined
        ? { ...current.scores, [skill]: current.scores[skill] ? Math.round(current.scores[skill] * 0.65 + score * 0.35) : score }
        : current.scores;
      return {
        ...current,
        completedByDate: { ...current.completedByDate, [today]: nextCompleted },
        scores: nextScores,
        studyDays: current.studyDays.includes(today) ? current.studyDays : [...current.studyDays, today],
        totalStudyMinutes: current.totalStudyMinutes + (alreadyDone ? 0 : minutes),
        readingWordsPerMinute: wordsPerMinute ?? current.readingWordsPerMinute,
      };
    });
  }, [update]);

  const recordWordAnswer = useCallback((wordId: string, correct: boolean) => {
    const today = getTodayKey();
    update((current) => {
      const old = current.wordMemory[wordId] ?? { seen: 0, correct: 0, incorrect: 0, lastSeen: today };
      return {
        ...current,
        wordMemory: {
          ...current.wordMemory,
          [wordId]: {
            seen: old.seen + 1,
            correct: old.correct + (correct ? 1 : 0),
            incorrect: old.incorrect + (correct ? 0 : 1),
            lastSeen: today,
          },
        },
      };
    });
  }, [update]);

  const rememberMistake = useCallback((mistake: string) => {
    const text = mistake.trim();
    if (!text) return;
    update((current) => ({ ...current, mistakeMemory: [text, ...current.mistakeMemory].slice(0, 40) }));
  }, [update]);

  const resolveMistakeAt = useCallback((index: number) => {
    update((current) => ({
      ...current,
      mistakeMemory: current.mistakeMemory.filter((_, itemIndex) => itemIndex !== index),
    }));
  }, [update]);

  const addChatMessage = useCallback((role: ChatEntry['role'], text: string) => {
    const entry: ChatEntry = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, role, text, createdAt: new Date().toISOString() };
    update((current) => ({ ...current, chatMessages: [...current.chatMessages, entry].slice(-80) }));
  }, [update]);

  const clearChatMessages = useCallback(() => {
    update((current) => ({ ...current, chatMessages: [] }));
  }, [update]);

  const rememberInterviewQuestion = useCallback((question: string) => {
    const trimmed = question.trim();
    if (!trimmed) return;
    update((current) => ({ ...current, interviewQuestions: [...current.interviewQuestions, trimmed].slice(-100) }));
  }, [update]);

  const saveInterviewTurn = useCallback((question: string, answer: string, feedback: string, score: number) => {
    const turn: InterviewTurn = {
      id: `${Date.now()}`,
      date: new Date().toISOString(),
      question,
      answer,
      feedback,
      score,
    };
    update((current) => ({ ...current, interviewHistory: [turn, ...current.interviewHistory].slice(0, 80) }));
  }, [update]);

  const saveWritingDraft = useCallback((prompt: string, text: string) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    const draft: WritingSubmission = {
      id: 'current-writing-draft',
      date: new Date().toISOString(),
      prompt,
      text,
      score: 0,
      feedback: '',
      status: 'draft',
    };
    update((current) => ({
      ...current,
      writingSubmissions: [draft, ...current.writingSubmissions.filter((item) => item.id !== draft.id)].slice(0, 30),
    }));
  }, [update]);

  const saveWritingSubmission = useCallback((prompt: string, text: string, score: number, feedback: string) => {
    const submission: WritingSubmission = {
      id: `${Date.now()}`,
      date: new Date().toISOString(),
      prompt,
      text,
      score,
      feedback,
      status: 'reviewed',
    };
    update((current) => ({
      ...current,
      writingSubmissions: [submission, ...current.writingSubmissions.filter((item) => item.id !== 'current-writing-draft')].slice(0, 30),
    }));
  }, [update]);

  const finishAssessment = useCallback((scores: SkillScores) => {
    const overall = average(Object.values(scores));
    let placedLevel = stateRef.current.profile?.level ?? 1;
    let promoted = false;
    update((current) => {
      const initialAssessment = current.assessmentHistory.length === 0;
      placedLevel = initialAssessment ? placementLevel(overall) : current.profile?.level ?? 1;
      const passesEverySkill = Object.values(scores).every((score) => score >= 80);
      if (!initialAssessment && passesEverySkill && placedLevel < 8) {
        placedLevel += 1;
        promoted = true;
      }
      return {
        ...current,
        profile: current.profile ? { ...current.profile, level: placedLevel } : null,
        scores,
        assessmentHistory: [{ date: new Date().toISOString(), scores, overall }, ...current.assessmentHistory].slice(0, 24),
        studyDays: current.studyDays.includes(getTodayKey()) ? current.studyDays : [...current.studyDays, getTodayKey()],
      };
    });
    return { placedLevel, promoted };
  }, [update]);

  const resetProgress = useCallback(() => {
    stateRef.current = emptyLearningState;
    setState(emptyLearningState);
    setStorageError(false);
    AsyncStorage.removeItem(STORAGE_KEY).catch(() => setStorageError(true));
  }, []);

  const value = useMemo<LearningContextValue>(() => ({
    state,
    ready,
    storageError,
    saveProfile,
    updateProfile,
    completeActivity,
    recordWordAnswer,
    rememberMistake,
    resolveMistakeAt,
    addChatMessage,
    rememberInterviewQuestion,
    saveInterviewTurn,
    saveWritingDraft,
    saveWritingSubmission,
    clearChatMessages,
    finishAssessment,
    resetProgress,
  }), [
    state,
    ready,
    storageError,
    saveProfile,
    updateProfile,
    completeActivity,
    recordWordAnswer,
    rememberMistake,
    resolveMistakeAt,
    addChatMessage,
    rememberInterviewQuestion,
    saveInterviewTurn,
    saveWritingDraft,
    saveWritingSubmission,
    clearChatMessages,
    finishAssessment,
    resetProgress,
  ]);

  return <LearningContext.Provider value={value}>{children}</LearningContext.Provider>;
}

export function useLearning() {
  const context = useContext(LearningContext);
  if (!context) throw new Error('useLearning must be used inside LearningProvider.');
  return context;
}