import {
  useCreateLearningCoach,
  useTranscribeLearningAudio,
  type CreateLearningCoachMutationVariables,
} from '@workspace/api-client-react';
import type { SkillKey } from '@/constants/learning';

export type CoachTask = 'chat' | 'writing' | 'speaking' | 'interview' | 'assessment' | 'grammar' | 'reading';

export function useLearningAI() {
  const coach = useCreateLearningCoach();
  const transcribe = useTranscribeLearningAudio();

  const askCoach = async (
    task: CoachTask,
    message: string,
    level: number,
    context?: string,
  ) => {
    const request: CreateLearningCoachMutationVariables['data'] = {
      task,
      message,
      level,
      context,
    };
    return coach.mutateAsync({ data: request });
  };

  const transcribeRecording = async (uri: string) => {
    const file = {
      uri,
      name: 'english-journey-speaking.m4a',
      type: 'audio/mp4',
    } as unknown as Blob;
    return transcribe.mutateAsync({ data: { audio: file } });
  };

  return {
    askCoach,
    transcribeRecording,
    busy: coach.isPending || transcribe.isPending,
  };
}

export function getNetworkMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  if (error && typeof error === 'object' && 'status' in error) {
    const status = (error as { status?: unknown }).status;
    if (status === 429) return 'Please wait a moment before trying another AI activity.';
    if (status === 404) return 'The AI API route was not found. The app may need to be published again.';
    if (status === 503) {
      return message.replace(/^HTTP 503[^:]*:\s*/, '') || 'The AI service is unavailable. Check the server configuration and try again.';
    }
    if (status === 502) {
      return message.replace(/^HTTP 502[^:]*:\s*/, '') || 'The AI provider could not complete the request. Please try again.';
    }
    if (typeof status === 'number' && status >= 400 && status < 500) {
      return message.replace(/^HTTP \d{3}[^:]*:\s*/, '') || `The AI request was rejected (HTTP ${status}).`;
    }
    if (typeof status === 'number' && status >= 500) {
      return `The AI server returned an error (HTTP ${status}). Please try again shortly.`;
    }
  }
  if (/network request failed|failed to fetch|network error/i.test(message)) {
    return 'Could not reach the learning server. Check your internet connection and try again.';
  }
  if (error instanceof Error && error.name === 'AbortError') {
    return 'The AI request timed out. Check your connection and try again.';
  }
  return message || 'The AI request could not be completed. Please try again.';
}

export function skillForTask(task: string): SkillKey | undefined {
  if (task === 'writing' || task === 'speaking' || task === 'interview' || task === 'reading') return task;
  if (task === 'grammar') return 'grammar';
  if (task === 'chat') return undefined;
  return undefined;
}