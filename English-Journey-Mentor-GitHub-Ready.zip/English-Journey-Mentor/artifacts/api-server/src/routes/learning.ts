import { Router, type IRouter, type NextFunction, type Request, type Response } from "express";
import multer from "multer";
import OpenAI, { toFile } from "openai";

const router: IRouter = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 18 * 1024 * 1024, files: 1 },
});

const allowedTasks = new Set([
  "chat",
  "writing",
  "speaking",
  "interview",
  "assessment",
  "grammar",
  "reading",
]);

const windows = new Map<string, { startedAt: number; count: number }>();

function limitAiRequests(req: Request, res: Response, next: NextFunction) {
  const now = Date.now();
  const key = req.ip ?? req.socket.remoteAddress ?? "unknown";
  const current = windows.get(key);
  if (!current || now - current.startedAt >= 60_000) {
    windows.set(key, { startedAt: now, count: 1 });
    return next();
  }
  current.count += 1;
  if (current.count > 20) {
    return res.status(429).json({ error: "Please wait a moment before trying another AI activity." });
  }
  return next();
}

function getClient() {
  const apiKey = process.env["OPENAI_API_KEY"];
  if (!apiKey) return null;
  return new OpenAI({ apiKey });
}

function getUpstreamErrorSummary(error: unknown) {
  if (!error || typeof error !== "object") {
    return { name: "UnknownError" };
  }
  const candidate = error as {
    name?: unknown;
    status?: unknown;
    code?: unknown;
    requestID?: unknown;
  };
  return {
    name: typeof candidate.name === "string" ? candidate.name : "OpenAIError",
    status: typeof candidate.status === "number" ? candidate.status : undefined,
    code: typeof candidate.code === "string" ? candidate.code : undefined,
    requestId: typeof candidate.requestID === "string" ? candidate.requestID : undefined,
  };
}

function sendUpstreamError(req: Request, res: Response, error: unknown, logMessage: string) {
  const summary = getUpstreamErrorSummary(error);
  req.log.error({ upstreamError: summary }, logMessage);

  if (summary.status === 401 || summary.status === 403) {
    return res.status(503).json({
      error: "The AI provider rejected the server credentials. Check the saved OpenAI secret.",
    });
  }
  if (summary.status === 429) {
    return res.status(429).json({ error: "The AI provider is temporarily rate limited. Please try again shortly." });
  }
  if (!summary.status) {
    return res.status(503).json({ error: "The AI provider is temporarily unreachable." });
  }
  return res.status(502).json({ error: "The AI provider could not complete this request. Please try again." });
}

router.post("/learning/coach", limitAiRequests, async (req, res) => {
  const body: unknown = req.body;
  if (
    !body ||
    typeof body !== "object" ||
    !("task" in body) ||
    !("message" in body) ||
    !("level" in body)
  ) {
    return res.status(400).json({ error: "A task, message, and learner level are required." });
  }

  const { task, message, level, context } = body as {
    task: unknown;
    message: unknown;
    level: unknown;
    context?: unknown;
  };
  if (
    typeof task !== "string" ||
    !allowedTasks.has(task) ||
    typeof message !== "string" ||
    message.trim().length === 0 ||
    message.length > 10_000 ||
    typeof level !== "number" ||
    !Number.isInteger(level) ||
    level < 1 ||
    level > 8 ||
    (context !== undefined && (typeof context !== "string" || context.length > 4_000))
  ) {
    return res.status(400).json({ error: "The learning request is not valid." });
  }

  const client = getClient();
  if (!client) {
    return res.status(503).json({ error: "AI coaching is not configured on the server." });
  }

  try {
    const completion = await client.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 8192,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "You are English Journey, a supportive but honest English teacher for a learner at the stated CEFR-style level. Stay focused on teaching English. Give specific, actionable feedback without empty praise. For writing and speaking, assess understandable English fairly and never penalize an accent. Explain mistakes with original, problem, rule, corrected sentence, and a short practice. For interviews, respond to the learner and provide exactly one natural next interview question as the final line of feedback, formatted exactly as 'Next question: <question>'. If the learner context explicitly says they have finished the interview and want a summary, do not ask another question. For chat, answer the learner's English question clearly. Return only a JSON object with keys feedback (string), score (integer 0-100, use 0 when a score does not apply), corrections (array of concise strings), and focus (one short next practice target). Keep feedback under 150 words.",
        },
        {
          role: "user",
          content: `Activity: ${task}\nLearner level: ${level} of 8\n${context ? `Lesson context: ${context}\n` : ""}Learner response or question:\n${message}`,
        },
      ],
    });
    const content = completion.choices[0]?.message?.content ?? "";
    try {
      const parsed: unknown = JSON.parse(content);
      if (
        parsed &&
        typeof parsed === "object" &&
        "feedback" in parsed &&
        "score" in parsed &&
        "corrections" in parsed &&
        "focus" in parsed
      ) {
        const candidate = parsed as {
          feedback: unknown;
          score: unknown;
          corrections: unknown;
          focus: unknown;
        };
        return res.json({
          feedback: typeof candidate.feedback === "string" ? candidate.feedback : content,
          score:
            typeof candidate.score === "number"
              ? Math.max(0, Math.min(100, Math.round(candidate.score)))
              : 0,
          corrections: Array.isArray(candidate.corrections)
            ? candidate.corrections.filter((item): item is string => typeof item === "string").slice(0, 8)
            : [],
          focus: typeof candidate.focus === "string" ? candidate.focus : "Keep practising a little each day.",
        });
      }
    } catch {
      // The client still receives useful feedback when the model returns malformed JSON.
    }
    return res.json({
      feedback: content || "I couldn't prepare feedback for that response. Please try again.",
      score: 0,
      corrections: [],
      focus: "Try again with one short English response.",
    });
  } catch (error) {
    return sendUpstreamError(req, res, error, "English coaching request failed");
  }
});

router.post(
  "/learning/transcribe",
  limitAiRequests,
  upload.single("audio"),
  async (req, res) => {
    if (!req.file || req.file.size === 0) {
      return res.status(400).json({ error: "Record a short answer before sending it." });
    }
    const client = getClient();
    if (!client) {
      return res.status(503).json({ error: "AI speaking practice is not configured on the server." });
    }
    try {
      const audio = await toFile(
        req.file.buffer,
        req.file.originalname || "english-practice.m4a",
        { type: req.file.mimetype || "audio/m4a" },
      );
      const result = await client.audio.transcriptions.create({
        file: audio,
        model: "gpt-4o-mini-transcribe",
        prompt: "Transcribe the learner's spoken English accurately. Do not rewrite or correct their words.",
      });
      return res.json({ transcript: result.text });
    } catch (error) {
      return sendUpstreamError(req, res, error, "English audio transcription failed");
    }
  },
);

export default router;